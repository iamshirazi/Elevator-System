public class Controller {

    public static void main(String[] args) {
    	
    	
    	Input inputFile = new Input("14:05:15.0", "1 ", "Up  ", 2);
    	
    	
    	
    	
        Thread scheduler = new Thread(new Scheduler(), "scheduler");
        Thread floor = new Thread (new Floor(inputFile, 1), "floor");
        Thread elevator = new Thread (new Elevator(), "elevator");


        System.out.println("Starting Process...");
        floor.start();
        scheduler.start();
        elevator.start();
    }

}