
/**
 * Creates an Elevator thread which sends and receives packets.
 */

import java.io.*;
import java.net.*;

/**
 * @author Matthew
 *
 */
public class Elevator implements Runnable {

	private DatagramPacket sendPacket, receivePacket;
	private DatagramSocket sendReceiveSocket;
	private boolean[] carButtonSelected;
	private boolean upDirectionalLampIsOn;
	private boolean downDirectionalLampIsOn;
	private boolean motorOn;
	private boolean doorsOpen;
	private int currentFloorNumber;
	private boolean running;

	public Elevator() {

		carButtonSelected = new boolean[7];
		upDirectionalLampIsOn = false;
		downDirectionalLampIsOn = false;
		motorOn = false;
		doorsOpen = false;
		currentFloorNumber = (int) ((Math.random() + 1) * 7); // 1 through 7
		running = true;
			
		try {

			sendReceiveSocket = new DatagramSocket(5002);

		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
	}

	/**
	 * Finds the button pressed and sets it to true.
	 * 
	 * @param floor_num
	 * @return
	 */
	public boolean isButtonSelected(int floor_num) {

		return carButtonSelected[floor_num - 1] = true; // Floor - 1 because floor 1 is at position 0 in array.
	}

	/**
	 * Returns if the up button was pressed.
	 * 
	 * @return
	 */
	public boolean isUpDirectionLampOn() {

		return upDirectionalLampIsOn;
	}

	/**
	 * Returns if the down button was pressed.
	 * 
	 * @return
	 */
	public boolean isDownDirectionLampOn() {

		return downDirectionalLampIsOn;
	}

	/**
	 * Sets the corresponding button lamp to true, depending on which button is
	 * pressed.
	 * 
	 * @param direction
	 */
	public void setDirectionLamp(String direction) {

		if (direction.equals("Up  ")) {
			downDirectionalLampIsOn = false;
			upDirectionalLampIsOn = true;
		} else {
			upDirectionalLampIsOn = false;
			downDirectionalLampIsOn = true;
		}
	}

	/**
	 * Turns elevator on in a specified direction.
	 * 
	 * @param direction
	 */
	public void startElevator() {
		motorOn = true;
	}

	/**
	 * Stops the elevator.
	 */
	public void stopElevator() {
		motorOn = false;
	}

	/**
	 * Opens the elevator doors.
	 */
	public void openDoors() {

		doorsOpen = true;
	}

	/**
	 * Closes the elevator doors.
	 */
	public void closeDoors() {

		doorsOpen = false;
	}

	/**
	 * Receives packet and unpacks it, then calls sendPacket method.
	 */
	public void receivePacket() {
	
		String message = "";
		
		byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);

        try {
            System.out.println("Waiting...");
            sendReceiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("sendReceive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }
        
        String received = new String(data,0,receivePacket.getLength());  
        
        //System.out.println(received);
        
        if (received.equals("stopMotor")) {
        	System.out.println("");
			System.out.println("Stopping Elevator Motor");
			
        	stopElevator();
        	message = "motorStopped";
        }
        else if (received.equals("startMotor"))  {
        	System.out.println("");
			System.out.println("Starting elevator Motor");
		
        	message = "motorStarted";
        	startElevator();
        }
        else if (received.equals("openDoor")) {
        	System.out.println("");
			System.out.println("Opening Elevator Doors");

        	openDoors();
        	message = "doorsOpened";
        }
        else if (received.equals("closeDoor")) {
        	System.out.println("");
			System.out.println("Closing Elevator Doors");
        	
        	closeDoors();
        	message = "doorsClosed";
        }
        else if(received.equals("currentFloor")) {
        	System.out.println("");
			System.out.println("Sending Elevator Current Floor Number");
        	
        	message = String.valueOf(currentFloorNumber);
        }
        else if(received.equals("end")) {
        	running = false;
        	
        }
        else {
        	System.out.println("");
			System.out.println("Received Destination from floor");
			message = "destinationSelected";
        }
        
        byte msg[] = message.getBytes();
        sendPacket(msg, 5000);
	}

	/**
	 * Sends packet to Scheduler.
	 */
	public void sendPacket(byte message[], int port) {

		sendPacket = new DatagramPacket(message, message.length, receivePacket.getAddress(), port);

		try {
	         sendReceiveSocket.send(sendPacket);
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.exit(1);
	      }
	}

	@Override
	public void run() {
		while(running == true) {
    		receivePacket();
    	}
		sendReceiveSocket.close();
		System.out.println("");
		System.out.println("---- done ----");
		System.exit(0);
	}
}
