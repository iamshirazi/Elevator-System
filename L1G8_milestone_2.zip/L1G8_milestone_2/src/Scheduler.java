import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Scheduler implements Runnable{

    DatagramPacket sendPacket, receivePacket;
    DatagramSocket sendElevatorSocket, receiveSocket, sendFloorSocket;
    private boolean elevatorGoingUp;
    private boolean elevatorGoingDown;
    private String currentFloor;
    private String direction;
    private String time;
    private String message;
    private String destination;
    private String motor;
    private String door;
    private String elevatorFloor = "4";
    private int elevator;
    private boolean isElevator = false;
    private boolean running = true;
    private String elevatorCurrentFloor = "4";
    private ArrayList<String> requestedFloor = new ArrayList<String>();

    // Scheduler Class Constructor
    public Scheduler(){
        elevatorGoingDown = false;
        elevatorGoingUp = false;

        try{
            sendFloorSocket = new DatagramSocket();
            sendElevatorSocket = new DatagramSocket();

            receiveSocket = new DatagramSocket(5000);
        } catch (SocketException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    public boolean isElevatorGoingUp(){
        return elevatorGoingUp;
    }

    public int calculateTimeToWait(int floor1, int floor2){
        int difference = floor1 - floor2;
        int positiveDifference = Math.abs(difference);

        //default time from floor to floor is 7 seconds, with an additional 2 seconds per extra floor
        return ((positiveDifference - 1) * 2) + 7;

    }

    public boolean isElevatorGoingDown() {
        return elevatorGoingDown;
    }
    
    public String getMessage(){
        return message;
    }

    public void receivePacket(){
        byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);
        System.out.println("Server: Waiting for Packet.\n");

        try {
            System.out.println("Waiting...");
            receiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("Receive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }


        // The string we received from the floor
        String received = new String(data, 0, receivePacket.getLength());

        if(receivePacket.getPort() == 5001){
            if(received.equals("elevatorArrived")) {
                /*System.out.println("The elevator has arrived at " + currentFloor);
                message = "stopMotor";
                byte msg[] = message.getBytes();
                sendPacket(msg, 5002);*/
            } else if(received.equals("arrivedDestination")){
                /*System.out.println("The elevator arrived at floor" + destination);
                message = "stopMotor";
                byte msg[] = message.getBytes();
                sendPacket(msg, 5002);
                
                message = "end";
                msg = message.getBytes();
                sendPacket(msg, 5002);
                
                System.out.println("Process finished, terminating process...");
                running = false;*/
            }else{
                // convert the string back into an array.
                received = received.replace("[", "");
                received = received.replace("]", "");

                String[] receivedArr = received.split(", ");

                time = receivedArr[0];
                currentFloor = receivedArr[1];
                direction = receivedArr[2];
                destination = receivedArr[3];
                requestedFloor.add(receivedArr[1]);
                

                	
                System.out.println("A request for an elevator has been made at " + time + " on floor " + currentFloor + " they want to go " + direction);
                if(Integer.parseInt(elevatorFloor) < Integer.parseInt(currentFloor.trim())) {
                	message = "directionUp";
                    byte msg[] = message.getBytes();
                    System.out.println("Sending signal to Floor to set direction lamp...");
                    sendPacket(msg, 5001);
                } else if (Integer.parseInt(elevatorFloor) > Integer.parseInt(currentFloor.trim())) {
                	message = "directionDown";
                    byte msg[] = message.getBytes();
                    System.out.println("Sending signal to Floor to set direction lamp...");
                    sendPacket(msg, 5001);
                }
               
                String request = "requestedFloor-"+ currentFloor.trim();
                byte elevator[] = request.getBytes();
                System.out.println("Sending current floor data to Elevator system..");
                sendPacket(elevator, 5002);

                door = "closeDoor";
                byte closeDoor[] = door.getBytes();
                System.out.println("Sending signal to Elevator to close door...");
                sendPacket(closeDoor, 5002);
                    
                /*motor = "startMotor";
                byte motorBytes[] = motor.getBytes();
                System.out.println("Sending signal to Elevator to start motor...");
				sendPacket(motorBytes, 5002);*/

            }
        } else if(receivePacket.getPort() == 5002){
            
        	String[] receivedArr;
        	
        	
        	if(received.contains("-")) {
        		receivedArr = received.split("-");
        		received = receivedArr[0];
        		elevatorCurrentFloor = receivedArr[1];
        	}
        	
        	
        	switch(received){
                case "motorStarted":
                    int passengerFloor = Integer.parseInt(currentFloor.trim());
                    int destinationFloor = Integer.parseInt(destination.trim());
                    System.out.println("Elevator Started Moving...");
                    /*if(!isElevator){
                    	
                    	
                        try {
                            System.out.println("Elevator moving to floor...");
                            //The thread will sleep for the calculated amount of time
                            
                            Thread.sleep(calculateTimeToWait(passengerFloor, elevator) * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        isElevator = true;
                    } else if (isElevator){
                    	
                        try {
                            System.out.println("Elevator moving to floor...");
                            //The thread will sleep for the calculated amount of time
                            Thread.sleep(calculateTimeToWait(passengerFloor, destinationFloor) * 1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }*/
                    break;
                case "motorStopped":
                    if(direction.equals("Up  ")) {
                        message = "upButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor to turn button lamp off...");
                        sendPacket(msg, 5001);

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator to open door...");
                        sendPacket(openDoor, 5002);
                    }else if(direction.equals("Down  ")) {
                        message = "downButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor turn button lamp off...");
                        sendPacket(msg, 5001);

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator to open door...");
                        sendPacket(openDoor, 5002);
                    }
                    break;
                case "doorsOpened":
                    message = "selectFloor";
                    byte msg[] = message.getBytes();
                    System.out.println("Sending signal to Floor to send selected floor to Elevator...");
                    sendPacket(msg, 5001);
                    break;
                case "doorsClosed":
                	if(Integer.parseInt(elevatorCurrentFloor) > Integer.parseInt(destination)) {
                		message = "startMotor-Down";
                	} else if (Integer.parseInt(elevatorCurrentFloor) < Integer.parseInt(destination)) {
                		message = "startMotor-Up";
                	} else {
                		System.out.println("It Broke :(");
                		break;
                	}
                	
                    
                    byte door[] = message.getBytes();
                    System.out.println("Sending signal to Elevator to start motor...");
                    sendPacket(door, 5002);
                    break;
                case "destinationSelected":
                	passengerFloor = Integer.parseInt(currentFloor.trim());
                    destinationFloor = Integer.parseInt(destination.trim());
                	if(destinationFloor > passengerFloor) {
                		message = "UpDirectionLampOn";
                	} else if(destinationFloor < passengerFloor) {
                		message = "DownDirectionLampOn";
                	}else {
                		message = "directionLampOff";
                	}
                	
                	msg = message.getBytes();
                    System.out.println("Sending signal to Floor to change direction lamp...");
                    sendPacket(msg, 5001);
                    
                    String doorState = "closeDoor";
                    byte closeDoor[] = doorState.getBytes();
                    System.out.println("Sending signal to Elevator to close door...");
                    sendPacket(closeDoor, 5002);
                	break;
                case "elevatorArrived":
                	 System.out.println("The elevator has arrived at " + elevatorCurrentFloor);
                     
                	 for(int i = 0; i < requestedFloor.size(); i++) {
                		 if(elevatorCurrentFloor.equals(requestedFloor.get(i).trim())) {
                			 requestedFloor.remove(i);
                			 message = "stopMotor";
                             msg = message.getBytes();
                             sendPacket(msg, 5002);
                		 }
                	 }
                	 
                     if(elevatorCurrentFloor.equals(destination) && requestedFloor.size() == 0) {
                    	 message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, 5002);
                         
                         
                    	 message = "end";
                    	 msg = message.getBytes();
                    	 sendPacket(msg, 5000);
                         sendPacket(msg, 5002);
                         System.out.println("Process finished, terminating process...");
                         running = false;
                     } else if(elevatorCurrentFloor.equals(destination) && requestedFloor.size() > 0) {
                    	 System.out.println("Continue Moving 1");
                    	 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, 5002);
                     }else if (!elevatorCurrentFloor.equals(destination) && requestedFloor.size() > 0) {
                    	 System.out.println("Continue Moving 2");
                    	 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, 5002);
                     }
                     break;
                default:
                	if(!received.equals("")) {
                		elevator = Integer.parseInt(received);
                	}
                    break;
     
            }
        }

    }

    public void sendPacket(byte[] message, int port) {
        sendPacket = new DatagramPacket(message, message.length, receivePacket.getAddress(), port);
        if(port == 5001) {
            try {
                sendFloorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else if (port == 5002){
            try {
                sendElevatorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }


    @Override
    public void run() {
    	while(running == true) {
    		receivePacket();
    	}
        sendFloorSocket.close();
        sendElevatorSocket.close();
        receiveSocket.close();
        //System.exit(0);
    }
}
