
import java.io.*;
import java.net.*;
import java.util.Arrays;

public class Floor implements Runnable {

	DatagramPacket sendPacket, receivePacket;
	DatagramSocket sendReceiveSocket;
	
	// Input Class Object
	Input input;
	
	// Which button has been selected (lamp turns on)
	private boolean upButtonLampIsOn;
    private boolean downButtonLampIsOn;
    
    
    // Which direction the elevator is going (direction lamp turns on)
    private boolean upDirectionalLampIsOn;
    private boolean downDirectionalLampIsOn;
    
    // Current Floor number
    private int floorNumber;
	
	
	
    // Class constructor
    //   Takes in: 
    //		- Array of Input class objects 
    //		- integer
	Floor(Input inputFile, int floor)
	{
		input = inputFile;
		upButtonLampIsOn = false;
		downButtonLampIsOn = false;
		upDirectionalLampIsOn = false;
		downDirectionalLampIsOn = false;
		floorNumber = floor;
		
		
		try {
			// set up the socket
			//	set the port to 5001
			sendReceiveSocket = new DatagramSocket(5001);
		} catch (SocketException se) {   // failed to create socket
			se.printStackTrace();
			System.exit(1);
		}
	} // End of Constructor Class
	
	
	
	
	//--------------------------------------------//
	//-----     Getter and Setter Section    -----//
	//--------------------------------------------//
	
  // Check if the buttons on the up and down buttons are on
	public boolean isUpButtonLampOn(){
		return upButtonLampIsOn;
	}

	public boolean isDownButtonLampOn() {
		return downButtonLampIsOn;
	}

  // Check if the up or down directional lamps are on
	public boolean isDownDirectionalLampOn() {
		return downDirectionalLampIsOn;
	}

	public boolean isUpDirectionalLampOn() {
		return upDirectionalLampIsOn;
	}

  // sets the value of the up or down directional lamps
	public void setUpDirLampIsOn(boolean isOn) {
		upDirectionalLampIsOn = isOn;
	}

	public void setDownDirLampIsOn(boolean isOn) {
		downDirectionalLampIsOn = isOn;
	}
	
	
	public Input getInputFile(){
        return input;
    }

    public int getFloorNumber(){
        return floorNumber;
    }
	
	
	
	//---------------------------------------------//
	//-----  End of Getter and Setter Section -----//
	//---------------------------------------------//
	
	
	
	
	public void sendAndReceive() 
	{
		// user presses button and it lights up the buttons
		if(input.direction.equals("Up  ")){
			upButtonLampIsOn = true;
		}
		else if (input.direction.equals("Down")){
			downButtonLampIsOn = true;
		}
		
		
		// process the input file
		String[] inputArr = new String[4];
		inputArr[0] = input.timestamp;
		inputArr[1] = input.callingFloor;
		inputArr[2] = input.direction;
		inputArr[3] = Integer.toString(input.destination);

		
		
		
		// next we convert the array Input into a string, and then we convert the string into an array of bytes to send them.
		byte request[] = Arrays.toString(inputArr).getBytes();
		
		try { // Make Datagram Packet
			// 5000 refers to the scheduler.
			sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5000);
		} catch (UnknownHostException e) {
	         e.printStackTrace();
	         System.exit(1);
	    }
		
		
		System.out.println("");
		System.out.println("Floor Calling Elevator. Contacting Scheduler");
		System.out.println("");

		
		try { // Send the Datagram packet
	         sendReceiveSocket.send(sendPacket);
	      } catch (IOException e) {
	         e.printStackTrace();
	         System.exit(1);
	      }
		
		
		System.out.println("");
		System.out.println("Floor Has Contacted Scheduler");
		System.out.println("");
		
		
		byte data[] = new byte[100];
		receivePacket = new DatagramPacket(data, data.length);
		
		// retrieve the data sent from the scheduler 
		try { 
			// Block until a datagram is received via sendReceiveSocket.  
			sendReceiveSocket.receive(receivePacket);
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		// convert the data to a string format
		String dataReceived = new String(data, 0, receivePacket.getLength());   
		
		//String arrivalResponse;
		//byte response[];
		
		// Switch statement to decide how to process the order from the scheduler.
		switch(dataReceived){
			
			case "directionNone":
				System.out.println("");
				System.out.println("Elevator not moving");
				System.out.println("set both direction lamps off.");
				System.out.println("");
				upDirectionalLampIsOn = false;
				downDirectionalLampIsOn = false;
				break;
							
				
			case "directionUp":
				System.out.println("");
				System.out.println("set Up direction lamps on.");
				System.out.println("");
				upDirectionalLampIsOn = true;
				downDirectionalLampIsOn = false;
				break;
					
						
			case "directionDown":
				System.out.println("");
				System.out.println("Elevator going down.");
				System.out.println("set down direction lamps on.");
				System.out.println("");
				upDirectionalLampIsOn = false;
				downDirectionalLampIsOn = true;
				break;
		} // End of Switch Statements
		
		
		
		
		
		//------------------------------//
		// wait for data from scheduler //
		//------------------------------//
		
		data = new byte[100];
		receivePacket = new DatagramPacket(data, data.length);
		
		try { // Receive Datagram Packet
			// Block until a datagram is received via sendReceiveSocket.  
			sendReceiveSocket.receive(receivePacket);
		} catch(IOException e) {
			System.out.println("Floor Broke");
			e.printStackTrace();
			System.exit(1);
		}
		
		
		// convert the data to a string format
		dataReceived = new String(data, 0, receivePacket.getLength());   
		
		if(dataReceived.equals("upButtonLampOff")) {
			System.out.println("");
			System.out.println("Turning Off Floor Up Button Lamp");
			setUpDirLampIsOn(false);
		}else if(dataReceived.equals("downButtonLampOff")) {
			System.out.println("");
			System.out.println("Turning Off Floor Down Button Lamp");
			setDownDirLampIsOn(false);
		}
		
		
		
		
		
		
		//------------------------------//
		// wait for data from scheduler //
		//------------------------------//
		
		// retrieve the data sent from the scheduler 
		try {
			// Block until a datagram is received via sendReceiveSocket.  
			sendReceiveSocket.receive(receivePacket);
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		System.out.println("");
		System.out.println("Selecting destination Floor");
		
		// convert the data to a string format
		dataReceived = new String(data, 0, receivePacket.getLength());   
		
		System.out.println("Data Received: " + dataReceived);
		
		byte selectDestination[];
		
		if(dataReceived.equals("selectFloor")) {
			selectDestination = Integer.toString(input.destination).getBytes();
			
			try {
				// 5002 refers to the Elevator.
				sendPacket = new DatagramPacket(selectDestination, selectDestination.length, InetAddress.getLocalHost(), 5002);
				
			} catch (UnknownHostException e) {
		         e.printStackTrace();
		         System.exit(1);
		    }
			
			System.out.println("");
			System.out.println("sending destination to elevator");
			try { // Send the Datagram packet
		         sendReceiveSocket.send(sendPacket);
		      } catch (IOException e) {
		         e.printStackTrace();
		         System.exit(1);
		      }
			
		}
		
		
		
		
		
		//-----------------------------------//
		// Wait for directive from scheduler //
		//-----------------------------------//
		try { // Receive Datagram Packet
			// Block until a datagram is received via sendReceiveSocket.  
			sendReceiveSocket.receive(receivePacket);
		} catch(IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
		
		// convert the data to a string format
		dataReceived = new String(data, 0, receivePacket.getLength());   
		
		System.out.println("Data Received: " + dataReceived);
		
		// Switch statement to decide how to process the order from the scheduler.
		switch(dataReceived){		
			case "directionLampOff":
				System.out.println("");
				System.out.println("Elevator stopped moving.");
				System.out.println("set both direction lamps off.");
				System.out.println("");
				upDirectionalLampIsOn = false;
				downDirectionalLampIsOn = false;
				break;
				
				
			case "UpDirectionLampOn":
				System.out.println("");
				System.out.println("Elevator going up.");
				System.out.println("set Up direction lamps on.");
				System.out.println("");
				upDirectionalLampIsOn = true;
				downDirectionalLampIsOn = false;
				break;
			
				
			case "DownDirectionLampOn":
				System.out.println("");
				System.out.println("Elevator going down.");
				System.out.println("set down direction lamps on.");
				System.out.println("");
				upDirectionalLampIsOn = false;
				downDirectionalLampIsOn = true;
				break;
		} // End of Switch Statements
		
		
		
		//-------------------------------//
		// Signal the end of the program //
		//-------------------------------//
		try {
			Thread.sleep(500);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String End = "arrivedDestination";
		byte programEnd[] = End.getBytes();
		
		System.out.println("");
		System.out.println("Elevator arrived at destination, notifying scheduler");
		
		try { // Make Datagram Packet
			// 5000 refers to the scheduler.
			sendPacket = new DatagramPacket(programEnd, programEnd.length, InetAddress.getLocalHost(), 5000);
		} catch (UnknownHostException e) {
	         e.printStackTrace();
	         System.exit(1);
	    }
		
		try { // Send the Datagram packet
	         sendReceiveSocket.send(sendPacket);
	      } catch (IOException e) {
	         e.printStackTrace();
	         System.exit(1);
	      }
		
		
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	} // End of sendAndReceive()
	
	
	
	
	@Override
	public void run()
	{
		sendAndReceive();
		sendReceiveSocket.close();
	}
}
