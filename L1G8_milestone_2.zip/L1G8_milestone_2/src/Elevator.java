/**
 * Creates an Elevator thread which sends and receives packets.
 */

import java.io.*;
import java.net.*;

/**
 * @author Matthew
 *
 */
public class Elevator implements Runnable {

	private DatagramPacket sendPacket, receivePacket;
	private DatagramSocket sendReceiveSocket;
	private boolean[] carButtonSelected; 
	private boolean upDirectionalLampIsOn;
	private boolean downDirectionalLampIsOn;
	private boolean motorOn;
	private boolean doorsOpen;
	private int currentFloorNumber; // Floor that the Elevator is currently on.
	private boolean running; // When elevator has picked up the passenger and reached the passenger's destination, running = false. True otherwise.
	String message;
	
	public Elevator() {
		
		carButtonSelected = new boolean[7];
		upDirectionalLampIsOn = false;
		downDirectionalLampIsOn = false;
		motorOn = false;
		doorsOpen = false;
		currentFloorNumber = 4;
		running = true;
			
		try {

			sendReceiveSocket = new DatagramSocket(5002);

		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public String getMessage(){
        return message;
    }
	
	public void stopRunning() { 
		running = false; 
		sendReceiveSocket.close();
	}

	/**
	 * Finds the button pressed and sets it to true.
	 * 
	 * @param floor_num
	 * @return
	 */
	public boolean isButtonSelected(int floor_num) {
		return carButtonSelected[floor_num - 1] = true; // Floor - 1 because floor 1 is at position 0 in array.
	}

	/**
	 * Returns if the up button was pressed.
	 * 
	 * @return
	 */
	public boolean isUpDirectionLampOn() {
		return upDirectionalLampIsOn;
	}

	/**
	 * Returns if the down button was pressed.
	 * 
	 * @return
	 */
	public boolean isDownDirectionLampOn() {
		return downDirectionalLampIsOn;
	}

	/**
	 * Sets the corresponding button lamp to true, depending on which button is
	 * pressed.
	 * 
	 * @param direction
	 */
	public void setDirectionLamp(String direction) {
		if (direction.equals("Up")) {
			downDirectionalLampIsOn = false;
			upDirectionalLampIsOn = true;
		} else if (direction.equals("Down")) {
			upDirectionalLampIsOn = false;
			downDirectionalLampIsOn = true;
		}
	}
	
	/**
	 * Turns elevator on in a specified direction.
	 * 
	 * @param direction
	 */
	public void startElevator() {
		motorOn = true;
		String message = "motorStarted";
		byte msg[] = message.getBytes();
        sendPacket(msg, 5000);
        try {
        	Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
	}

	/**
	 * Stops the elevator.
	 */
	public void stopElevator() {
		motorOn = false;
	}

	/**
	 * Opens the elevator doors.
	 */
	public void openDoors() {
		doorsOpen = true;
	}

	/**
	 * Closes the elevator doors.
	 */
	public void closeDoors() {
		doorsOpen = false;
	}

	/**
	 * Receives packet and unpacks it, then calls sendPacket method.
	 */
	public void receivePacket() {
		message = "";
		
		byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);

        try {
            System.out.println("Waiting...");
            sendReceiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("sendReceive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }
        
        // Gets message and turns it into a String.
        String received = new String(data,0,receivePacket.getLength());  
        
        String[] receivedArr;
        String direction = "";
    	
        /*
         * Splits the string if the message contained a direction. 
         * The elevator has to go either Up or Down to the passenger's chosen destination.
         * Direction is either Up (elevator goes Up to the destination) or Down.
         */
    	if(received.contains("-")) {
    		receivedArr = received.split("-");
    		received = receivedArr[0];
    		direction = receivedArr[1];
    	}
    	
    	// Sets direction to "Up" or "Down"
    	setDirectionLamp(direction); 
        
    	/*
    	 * All these if statements do a specific task for a specific message.
    	 * Sends a response message at the very end.
    	 */
        if (received.equals("stopMotor")) {
        	System.out.println("");
			System.out.println("Stopping Elevator Motor");
			
        	stopElevator();
        	message = "motorStopped";
        }
        
        else if (received.equals("startMotor"))  {
        	System.out.println("");
			System.out.println("Starting elevator Motor");
        	startElevator();
        	
        	try {
            	Thread.sleep(3000);
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
        	if(upDirectionalLampIsOn) {
        		currentFloorNumber++;
        	} else if(downDirectionalLampIsOn) {
        		currentFloorNumber--;
        	} else {
        		System.out.println("Something's not right here............");
        	}
        	System.out.println("");
			System.out.println("Elevator is at floor: " + currentFloorNumber);
        	message = "elevatorArrived-" + currentFloorNumber;
        }
        else if (received.equals("openDoor")) {
        	System.out.println("");
			System.out.println("Opening Elevator Doors");

        	openDoors();
        	message = "doorsOpened";
        }
        else if (received.equals("closeDoor")) {
        	System.out.println("");
			System.out.println("Closing Elevator Doors");
        	
        	closeDoors();
        	message = "doorsClosed";
        }
        else if(received.equals("currentFloor")) {
        	System.out.println("");
			System.out.println("Sending Elevator Current Floor Number");
        	
        	message = String.valueOf(currentFloorNumber);
        }
        else if(received.equals("end")) {
        	running = false;
        	
        }
        else if(received.equals("continueMoving")) {
        	try {
            	Thread.sleep(4000); // 4 seconds per floor.
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
        	if(upDirectionalLampIsOn) {
        		// Elevator continues UP a floor.
        		currentFloorNumber++;
        	} else if(downDirectionalLampIsOn) {
        		// Elevator continues moving DOWN a floor.
        		currentFloorNumber--;
        	}
        	System.out.println("");
			System.out.println("Elevator is at floor: " + currentFloorNumber);
        	message = "elevatorArrived-" + currentFloorNumber;
        }
        else if(received.equals("requestedFloor")) {
        	System.out.println("Elevator received floor request");
        	
        	if(currentFloorNumber > Integer.parseInt(direction)) {
        		upDirectionalLampIsOn = false;
        		downDirectionalLampIsOn = true;
        	} else if (currentFloorNumber > Integer.parseInt(direction)) {
        		upDirectionalLampIsOn = true;
        		downDirectionalLampIsOn = false;
        	} else {
        		upDirectionalLampIsOn = false;
        		downDirectionalLampIsOn = false;
        	}	
        }
        else {
        	/* Program enters this else statement when floor has sent the destination to the Elevator.
        	 * Elevator sends a response message to the Scheduler.
        	 */
        	System.out.println("----> " + received);
        	System.out.println("");
			System.out.println("Received Destination from floor");
			message = "destinationSelected";
        }
        /*
         * Message (regardless of what it is) is sent to the Scheduler.
         * Message is printed to the console.
         */
        System.out.println("Elevator message = " + message);
        byte msg[] = message.getBytes();
        sendPacket(msg, 5000);
	}
	
	/**
	 * Sends packet to Scheduler.
	 */
	public void sendPacket(byte message[], int port) {

		sendPacket = new DatagramPacket(message, message.length, receivePacket.getAddress(), port);

		try {
	         sendReceiveSocket.send(sendPacket);
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.exit(1);
	      }
	}

	@Override
	public void run() {
		while(running == true) {
    		receivePacket();
    	}
		sendReceiveSocket.close();
		System.out.println("");
		/*
		 * When Elevator is not running, Elevator thread ends.
		 */
		System.out.println("---- done ----");
		System.exit(0);
	}
}
