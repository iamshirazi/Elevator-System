import static org.junit.Assert.*;

public class FloorTest {

    Input inputFile = new Input("14:05:15.0", "1 ", "Up  ", 2);

    private Floor floor;

    @org.junit.Test
    public void inputTest() {
        floor = new Floor(inputFile, 1);
        assertEquals(floor.getFloorNumber(), 1);

    }

    @org.junit.Test
    public void floorTest() {
        floor = new Floor(inputFile, 1);
        floor.run();
    }

}