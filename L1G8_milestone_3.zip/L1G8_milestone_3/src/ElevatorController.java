import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;

public class ElevatorController {
    private ArrayList<Integer> elevatorPorts = new ArrayList<Integer>();
    private String[] message;
    private ArrayList<Thread> elevatorThreads = new ArrayList<Thread>();
    private boolean isReceived = false;

    private int initialPort = 5001;
    private DatagramSocket sendReceiveSocket;
    private DatagramPacket sendPacket, receivePacket;
    
    private String schedulerIP = "";

    public void setupElevators(){

        try { // Create a send and receive socket and assign it the port 6001
            sendReceiveSocket = new DatagramSocket(6001);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }

        byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);

        // retrieve the data sent from the scheduler
        try {
            // Block until a datagram is received via receiveSocket
            System.out.println("Waiting...");
            sendReceiveSocket.receive(receivePacket);
            System.out.println("Received!");
        } catch(IOException e) {
            System.out.println("Oops");
            e.printStackTrace();
            System.exit(1);
        }

        String received = new String(data, 0, receivePacket.getLength());
        schedulerIP = received;
        isReceived = true;

        if(isReceived) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("How many elevators do you want in the system?");
            String elevators = null;

            try {
                elevators = reader.readLine();
            } catch (IOException e) {
                e.printStackTrace();
            }

            int amountOfElevators = Integer.parseInt(elevators);
            
            String[] message = new String[amountOfElevators];

            for (int i = 0; i < amountOfElevators; i++) {
                elevatorPorts.add(i, initialPort);
                message[i] = elevatorPorts.get(i).toString();
                initialPort++;
            }

            for (int j = 0; j < elevatorPorts.size(); j++) {
                System.out.println(message[j]);
            }

            byte request[] = Arrays.toString(message).getBytes();

            try {
                sendPacket = new DatagramPacket(request, request.length, InetAddress.getByName(schedulerIP), 6002);
            } catch (UnknownHostException e) {
                e.printStackTrace();
                System.exit(1);
            }

            try { // Send the Datagram packet to the correct port
                sendReceiveSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }

            System.out.println("Elevator ports sent to Scheduler");
            
            
            
            data = new byte[100];
            receivePacket = new DatagramPacket(data, data.length);

            // retrieve the data sent from the scheduler
            try {
                // Block until a datagram is received via receiveSocket);
                sendReceiveSocket.receive(receivePacket);
            } catch(IOException e) {
                System.out.println("Oops");
                e.printStackTrace();
                System.exit(1);
            }
            
            received = new String(data, 0, receivePacket.getLength());
            
            
            sendReceiveSocket.close();

            for (int k = 1; k <= amountOfElevators; k++){
                elevatorThreads.add(new Thread(new Elevator(elevatorPorts.get(k - 1), schedulerIP, Integer.parseInt(received.trim())), ("elevator" + k)));
                elevatorThreads.get(k - 1).start();
                System.out.println(elevatorThreads.get(k - 1).getName());
            }
        }
    }


    public static void main(String[] args) {

        ElevatorController EC = new ElevatorController();
        EC.setupElevators();


    }

}
