import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Scheduler implements Runnable{

    DatagramPacket sendPacket, receivePacket;
    DatagramSocket sendElevatorSocket, receiveSocket, sendFloorSocket;
    //private boolean elevatorGoingUp;
    //private boolean elevatorGoingDown;
    private String currentFloor;
    private String direction;
    //private String time;
    private String message;
    //private String destination;
    //private String motor;
    //private String door;
    //private String elevatorFloor = "4";
    //private int elevator;
    //private boolean isElevator = false;
    private boolean running = true;
    //private String elevatorCurrentFloor = "4";
    private ArrayList<String[]> requestedFloor = new ArrayList<String[]>();
    private ArrayList<String> floorPorts = new ArrayList<String>();
    private ArrayList<String> elevatorPorts = new ArrayList<String>();
    private ArrayList<ElevatorCar> elevatorCars = new ArrayList<ElevatorCar>();

    
    
    // Scheduler Class Constructor
    public Scheduler(ArrayList<String> floorPorts, ArrayList<String> elevatorPorts){
    	
        try{ // Set up the Sockets
            sendFloorSocket = new DatagramSocket();
            sendElevatorSocket = new DatagramSocket();

            receiveSocket = new DatagramSocket(5000);
        } catch (SocketException e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        // Set the arrayLists
        this.floorPorts = floorPorts;
        this.elevatorPorts = new ArrayList<String>(elevatorPorts);
        
        int curFloor;
        // create the elevator car objects
        for(int i = 1; i < elevatorPorts.size(); i++) {
        	
        	curFloor = (int) (Math.random() * ((floorPorts.size()-1) - 1 + 1) + 1);
        	
        	System.out.println(elevatorPorts.size());
        	
        	System.out.println(curFloor);
        	System.out.println(elevatorPorts.get(i));
        	System.out.println(elevatorPorts.get(0));
        	elevatorCars.add(new ElevatorCar(curFloor, "None", Integer.parseInt(elevatorPorts.get(i)))); // create elevator care object
        
        	// Send a Message to the elevator to set the floor of the elevator
        	message = "setFloor=" + curFloor;
            byte[] msg = message.getBytes();
            sendPacket(msg, Integer.parseInt(elevatorPorts.get(i)), elevatorPorts.get(0));
        	
        }
        
        
    }
    
    
    public int findClosest(int requestedFloorNumber, String direction) {
		
		int floorsAway = 100; // place holder. means that the closest elevator is 100 floors away
		boolean foundClosest = false;
		
		int closestPort = 0; // holds the port of the closest elevator
		
		
		for (int i = 0; i < elevatorCars.size(); i++) {
		
			if (elevatorCars.get(i).getDirection().equals(direction) || elevatorCars.get(i).getDirection().equals("None")) {
				
				// both going up?
				if (elevatorCars.get(i).getCurrentFloor() - requestedFloorNumber < floorsAway) {
					floorsAway = elevatorCars.get(i).getCurrentFloor();
				}
				foundClosest = true;
				closestPort = elevatorCars.get(i).getPort();

				
			} 
			/*else if (foundClosest == false) {
				
				if (elevatorCars.get(i).getCurrentFloor() - requestedFloorNumber < floorsAway) {
					floorsAway = elevatorCars.get(i).getCurrentFloor();
				}
				
			}*/
			
		}
		
		System.out.println("The closest elevator is on floor: " + floorsAway);
		if(foundClosest = false) {
			return 0;
		} else {
			return closestPort;
		}
	}
    
    
    
    public int calculateTimeToWait(int floor1, int floor2){
        int difference = floor1 - floor2;
        int positiveDifference = Math.abs(difference);

        //default time from floor to floor is 7 seconds, with an additional 2 seconds per extra floor
        return ((positiveDifference - 1) * 2) + 7;

    }
    
    public String getMessage(){
        return message;
    }

    public void receivePacket(){
        byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);
        System.out.println("Server: Waiting for Packet.\n");

        try {
            System.out.println("Waiting...");
            receiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("Receive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }


        // The string we received from the floor
        String received = new String(data, 0, receivePacket.getLength());
        
        if(receivePacket.getPort() <= 4999){ // floor ports ----------------------------------------------------
        	// convert the string back into an array.
        	received = received.replace("[", "");
        	received = received.replace("]", "");

        	String[] receivedArr = received.split(", ");

        	//time = receivedArr[0];
        	currentFloor = receivedArr[1];
        	direction = receivedArr[2];
        	//destination = receivedArr[3];
        	//requestedFloor.add(receivedArr[1]);
                
        	int elevatorIndex = 0;
        	
        	for(int i = 0; i < elevatorCars.size(); i ++) {
        		if(elevatorCars.get(i).getCurrentFloor() == floorPorts.indexOf(Integer.toString(receivePacket.getPort()))) {
        			elevatorIndex = i;
        		}
        	}
        	
        	
        	System.out.println("A request for an elevator has been made on floor " + currentFloor + " they want to go " + direction);
        	//System.out.println("A request for an elevator has been made at " + time + " on floor " + currentFloor + " they want to go " + direction);
        	if(elevatorCars.get(elevatorIndex).getCurrentFloor() < Integer.parseInt(currentFloor.trim())) {
        		message = "directionUp";
        		byte msg[] = message.getBytes();
        		System.out.println("Sending signal to Floor to set direction lamp...");
        		sendPacket(msg, receivePacket.getPort(), floorPorts.get(0));
        	} else if (elevatorCars.get(elevatorIndex).getCurrentFloor() > Integer.parseInt(currentFloor.trim())) {
        		message = "directionDown";
        		byte msg[] = message.getBytes();
        		System.out.println("Sending signal to Floor to set direction lamp...");
        		sendPacket(msg, receivePacket.getPort(), floorPorts.get(0));
        	}
        	
        	String[] temp = new String[2];
        	
        	temp[0] = currentFloor.trim();
        	temp[1] = direction.trim();
        	
        	requestedFloor.add(temp);
        	
               

        	/*String request = "requestedFloor-"+ currentFloor.trim();
        	byte elevator[] = request.getBytes();
        	System.out.println("Sending current floor data to Elevator system..");
        	sendPacket(elevator, 5002, elevatorPorts.get(0));

        	door = "closeDoor";
        	byte closeDoor[] = door.getBytes();
        	System.out.println("Sending signal to Elevator to close door...");
        	sendPacket(closeDoor, 5002, elevatorPorts.get(0));*/
            
        	// ^^^ Moved to run()

        } else if(receivePacket.getPort() >= 5001){ // elevator ports  ----------------------------------------------------
            
        	String[] receivedArr = null;
        	
        	//String elevatorCurrentFloor;
        	
        	if(received.contains("-")) {
        		receivedArr = received.split("-");
        		received = receivedArr[0];
        		//elevatorCurrentFloor = receivedArr[1];
        	}
        	
        	int elevatorIndex = 0;
        	int floorPort = 0;
        	
        	for(int i = 0; i < elevatorCars.size(); i ++) {
        		if(elevatorCars.get(i).getPort() == receivePacket.getPort()) {
        			elevatorIndex = i;
        			
        			floorPort = Integer.parseInt(floorPorts.get(elevatorCars.get(i).getCurrentFloor()));
        		}
        	}
        	
        	String door = "";
        	switch(received){
                case "motorStarted":

                	for(int i = 0; i < elevatorCars.size(); i++) {
                		if(elevatorCars.get(i).getPort() == receivePacket.getPort()) {
                			elevatorCars.get(i).setDirection(receivedArr[1]);
                		}
                	}
                	
                    System.out.println("Elevator Started Moving...");
                    break;
                case "motorStopped":
                    if(direction.equals("Up  ")) {
                        message = "upButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor to turn button lamp off...");
                        sendPacket(msg, floorPort, floorPorts.get(0));

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator to open door...");
                        sendPacket(openDoor, receivePacket.getPort(), elevatorPorts.get(0));
                    }else if(direction.equals("Down  ")) {
                        message = "downButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor turn button lamp off...");
                        sendPacket(msg, floorPort, floorPorts.get(0));

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator to open door...");
                        sendPacket(openDoor, receivePacket.getPort(), elevatorPorts.get(0));
                    }
                    break;
                case "doorsOpened":
                	
                    message = "selectFloor-" + elevatorPorts.get(0) + "-" + receivePacket.getPort() + "-" + elevatorCars.get(elevatorIndex).getDirection();
                    byte msg[] = message.getBytes();
                    System.out.println("Sending signal to Floor to send selected floor to Elevator...");
                    sendPacket(msg, floorPort, floorPorts.get(0));
                    break;
                case "doorsClosed":
                	
                	message = "startMotor";
                	
                	/*if(elevatorCars.get(elevatorIndex).getCurrentFloor() > Integer.parseInt(destination)) {
                		message = "startMotor-Down";
                	} else if (elevatorCars.get(elevatorIndex).getCurrentFloor() < Integer.parseInt(destination)) {
                		message = "startMotor-Up";
                	}*/ 
                	/*else {
                		System.out.println("It Broke :(");
                		break;
                	}*/
                	
                	msg = message.getBytes();
                    System.out.println("Sending signal to Elevator to start motor...");
                    sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                    break;
                case "destinationSelected":
                	//passengerFloor = Integer.parseInt(currentFloor.trim());
                    //destinationFloor = Integer.parseInt(destination.trim());
                	/*if(destinationFloor > passengerFloor) {
                		message = "UpDirectionLampOn";
                	} else if(destinationFloor < passengerFloor) {
                		message = "DownDirectionLampOn";
                	}else {
                		message = "directionLampOff";
                	}*/
                	
                	/*msg = message.getBytes();
                    System.out.println("Sending signal to Floor to change direction lamp...");
                    sendPacket(msg, floorPort, floorPorts.get(0));*/
                    
                    String doorState = "closeDoor";
                    byte closeDoor[] = doorState.getBytes();
                    System.out.println("Sending signal to Elevator to close door...");
                    sendPacket(closeDoor, receivePacket.getPort(), elevatorPorts.get(0));
                	break;
                case "elevatorArrived":
                	
                	 System.out.println("The elevator " + (elevatorIndex + 1) + " has arrived at " + elevatorCars.get(elevatorIndex).getCurrentFloor());
                     
                	 
                	 elevatorCars.get(elevatorIndex).setFloor(Integer.parseInt(receivedArr[1]));
                	 
                	 
                	 if(receivedArr[2].equals("isDestination")) {
                		 message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                	 }
                	 
                	 if(receivedArr[3].equals("isFinalDestination")) {
                		 message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                	 } 
                	 else if(receivedArr[3].equals("isNotFinalDestination")) {
                		 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                	 }
                	 
                	 
                	 
                	 /*for(int i = 0; i < requestedFloor.size(); i++) {
                		 if(elevatorCurrentFloor.equals(requestedFloor.get(i)[0].trim())) {
                			 requestedFloor.remove(i);
                			 message = "stopMotor";
                             msg = message.getBytes();
                             sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                		 }
                	 }*/
                	 
                     /*if(elevatorCurrentFloor.equals(destination) && requestedFloor.size() == 0) {
                    	 message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));*/
                         
                         /**********
                          * 
                          * CHANGE
                          * 
                          **********/
                    	 /*message = "end";
                    	 msg = message.getBytes();
                    	 for(int i = 1; i < floorPorts.size(); i++) {// Send "end' Message to all floors
                    		 sendPacket(msg, Integer.parseInt(floorPorts.get(i)), floorPorts.get(0));
                    	 }
                    	 
                    	 for(int i = 1; i < elevatorPorts.size(); i++) { // Send "end' Message to all elevators
                    		 sendPacket(msg, Integer.parseInt(elevatorPorts.get(i)), elevatorPorts.get(0));
                    	 }
                         
                         System.out.println("Process finished, terminating process...");
                         running = false;*/
                         
                         /***************
                          * 
                          * 
                          ***************/
                         
                         
                     /*} else if(elevatorCurrentFloor.equals(destination) && requestedFloor.size() > 0) {
                    	 System.out.println("Continue Moving 1");
                    	 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                     }else if (!elevatorCurrentFloor.equals(destination) && requestedFloor.size() > 0) {
                    	 System.out.println("Continue Moving 2");
                    	 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                     }*/
                     break;
                default:
                	if(!received.equals("")) {
                		//elevator = Integer.parseInt(received);
                	}
                    break;
            }
        }

    }

    public void sendPacket(byte[] message, int port, String IP) {
        try {
			sendPacket = new DatagramPacket(message, message.length, InetAddress.getByName(IP), port);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        if(port <= 4999) {
            try {
                sendFloorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else if (port >= 5001){
            try {
                sendElevatorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }


    @Override
    public void run() {
    	while(running == true) {
    		
    		if(requestedFloor.size() != 0) {
    			
    			for(int i = 0; i < requestedFloor.size(); i ++) {
    				int tempPort = findClosest(Integer.parseInt(requestedFloor.get(i)[0]), requestedFloor.get(i)[1]);
    				
    				
    				if(tempPort != 0) {
    					
    					String door;
    					
    					String request = "requestedFloor-"+ requestedFloor.get(i)[0];
    		        	byte elevator[] = request.getBytes();
    		        	System.out.println("Requesting elevator " + (tempPort - 5000));
    		        	sendPacket(elevator, tempPort, elevatorPorts.get(0));

    		        	door = "closeDoor";
    		        	byte closeDoor[] = door.getBytes();
    		        	System.out.println("Sending signal to Elevator " + (tempPort - 5000) + " to close door...");
    		        	sendPacket(closeDoor, tempPort, elevatorPorts.get(0));
    				}	
    			}
    			
    		}
    		
    		
    		receivePacket();
    	}
        sendFloorSocket.close();
        sendElevatorSocket.close();
        receiveSocket.close();
        //System.exit(0);
    }
}
