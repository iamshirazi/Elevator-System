import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.lang.Math;

public class Scheduler implements Runnable{

    DatagramPacket sendPacket, receivePacket;
    DatagramSocket sendElevatorSocket, receiveSocket, sendFloorSocket;
    //private boolean elevatorGoingUp;
    //private boolean elevatorGoingDown;
    private String currentFloor;
    private String direction;
    //private String time;
    private String message;
    //private String destination;
    //private String motor;
    //private String door;
    //private String elevatorFloor = "4";
    //private int elevator;
    //private boolean isElevator = false;
    private boolean running = true;
    //private String elevatorCurrentFloor = "4";
    private ArrayList<String[]> requestedFloor = new ArrayList<String[]>();
    private ArrayList<String[]> servicingRequests= new ArrayList<String[]>();
    private ArrayList<String> floorPorts = new ArrayList<String>();
    private ArrayList<String> elevatorPorts = new ArrayList<String>();
    private ArrayList<ElevatorCar> elevatorCars = new ArrayList<ElevatorCar>();
    private int preferableCapactity; // Represents the preferable Capacity of elevator cars
    private int maxCapacity;        // Represents the max Capacity of elevator cars

    
    
    //-----  Scheduler Class Constructor  ------//
    public Scheduler(ArrayList<String> floorPorts, ArrayList<String> elevatorPorts, int preferableCapactity, int maxCapacity){
    	
        try{ // Set up the Sockets
            sendFloorSocket = new DatagramSocket();
            sendElevatorSocket = new DatagramSocket();

            receiveSocket = new DatagramSocket(5000);
        } catch (SocketException e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        // Set the arrayLists
        this.floorPorts = floorPorts;
        this.elevatorPorts = new ArrayList<String>(elevatorPorts);
        this.preferableCapactity = preferableCapactity;
        this.maxCapacity = maxCapacity;
        
        int curFloor;
        // create the elevator car objects
        for(int i = 1; i < elevatorPorts.size(); i++) {
        	
        	curFloor = (int) (Math.random() * ((floorPorts.size()-1) - 1 + 1) + 1);
        	
        	System.out.println(elevatorPorts.size());
        	
        	System.out.println(curFloor);
        	System.out.println(elevatorPorts.get(i));
        	System.out.println(elevatorPorts.get(0));
        	elevatorCars.add(new ElevatorCar(curFloor, "None", Integer.parseInt(elevatorPorts.get(i)))); // create elevator care object
        
        	// Send a Message to the elevator to set the floor of the elevator
        	message = "setFloor=" + curFloor;
            byte[] msg = message.getBytes();
            sendPacket(msg, Integer.parseInt(elevatorPorts.get(i)), elevatorPorts.get(0));
        }
        try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    } // End of Contructor
    
    
    
    //-----  findClosest(int, string) Method  -----//
    // - This method is used to determine the closest elevator to a requested floor and then assign that floor as a stop for the elevator.
    public int findClosest(int requestedFloorNumber, String direction) {
		
    	ArrayList<Integer[]> availableCars = new ArrayList<Integer[]>(); 	// Holds a list of the arrays of integers. The first index in the array is the index of a car (in the elevatorCarr arraylist) that is available. The second index is it's level of preference.
		int floorsAway = 100; 												// place holder. means that the closest elevator is 100 floors away
		int closestPort = 0; 												// holds the port of the closest elevator
		Integer[] preferredCar = new Integer[]{100, 100};					// Holds the index of the preferred car and it's level of preference
		boolean foundPreferred = false;										// tells us if we found a preferred elevator or not
		
		// Now, loop over the list of elevator cars
		for (int i = 0; i < elevatorCars.size(); i++) {
			
			// First, loop over the list of elevator cars and retrieve the elevators that are 
			//  under the maximum capacity and that are not already heading in the wrong direction.
			//  Add them into the list of available cars
			if(elevatorCars.get(i).getNumPassengers() < maxCapacity && (elevatorCars.get(i).getDirection().equals(direction) || elevatorCars.get(i).getDirection().equals("None"))) {
				
				availableCars.add(new Integer[] {i, 100}); // adds the index of the car and set's it's preference to 100
			}
		}
		
		// Next, we iterate over the list of available cars and we choose the preferred car
		// Car Preference is ordered as follows:
		//	1. Car already moving in desired direction AND under preferred capacity
		//  2. Car not moving, BUT when moving it CAN pick up passenger on the way (if going up, elevator is bellow passenger. if going down, elevator is above passenger) (Also car is therefore by default under preferred capacity, since it's not moving)
		//  3. Car not moving AND when moving it CAN NOT pick up passenger on the way (if going up, elevator is Above passenger. if going down, elevator is Below passenger) (Also car is therefore by default under preferred capacity, since it's not moving)
		//  
		//	4. Car already moving in desired direction AND is OVER preferred capacity BUT is UNDER Max Capacity
		// 	5. If there is no available cars, the floor will wait and try again later to be serviced.
		
		// The program will always pick whichever car is highest in the order of preference, however if two elevators are the same preference, it will pick the one that's closest 
		
		
		// Now we loop over the available cars and assign them the proper preference 
		for(int i = 0; i < availableCars.size(); i++){
			
			// Check for preference 1
			if( elevatorCars.get(availableCars.get(i)[0]).getDirection().equals(direction) && elevatorCars.get(availableCars.get(i)[0]).getNumPassengers() < preferableCapactity ) { availableCars.get(i)[1] = 1; }
			
			
			// Check for preference 2 and 3
			else if(elevatorCars.get(availableCars.get(i)[0]).getDirection().equals("None")) { // Check direction = None
				
				// Check for preference 2
				if( (direction.equals("Up") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() <= requestedFloorNumber)   ||   (direction.equals("Down") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() >= requestedFloorNumber) ) { availableCars.get(i)[1] = 2; }
				
				// Check for preference 3
				if( (direction.equals("Up") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() > requestedFloorNumber)   ||   (direction.equals("Down") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() < requestedFloorNumber) ) { availableCars.get(i)[1] = 3; }

			}
			
			// Check for preference 4
			else if( elevatorCars.get(availableCars.get(i)[0]).getDirection().equals(direction) && elevatorCars.get(availableCars.get(i)[0]).getNumPassengers() > preferableCapactity ) { availableCars.get(i)[1] = 4; }
			
		}
		
		
		// Next, compare the preferences. If two elevators have the same preference, pick the closest
		for(int i = 0; i < availableCars.size(); i++) {
			
			// Make sure the cars level of preference is between 1 and 4
			if(availableCars.get(i)[1] >= 1 && availableCars.get(i)[1] <= 4) {
				
				foundPreferred = true;
				
				// Check if the level of preference is smaller than the level of preference from the current preferred car.
				if(availableCars.get(i)[1] < preferredCar[1]) { // It is more preferred
					preferredCar = availableCars.get(i); // current car is the new preferred car
				}
				else if(availableCars.get(i)[1] == preferredCar[1]) { // They are equal in preference 
					
					// Choose the closest one
						// Checks the absolute value of the elevators current floor minus the request floor
					if( Math.abs( elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() - requestedFloorNumber )   <   Math.abs( elevatorCars.get(preferredCar[0]).getCurrentFloor() - requestedFloorNumber )) {
						preferredCar = availableCars.get(i);
					}
				}
			}
		}
		
		// Now, return the port of the 

		if(foundPreferred == true) { 	// We found a elevator car within our preference 
			System.out.println("The preferred elevator is on floor: " + elevatorCars.get(preferredCar[0]).getCurrentFloor());
			
			closestPort = elevatorCars.get(preferredCar[0]).getPort();
			
			return closestPort;
		} else { 						// We did not find a elevator car within our preference 
			
			return 0;
		}

	} // End of findClosest Method
    
    
    
    
    
    public int calculateTimeToWait(int floor1, int floor2){
        int difference = floor1 - floor2;
        int positiveDifference = Math.abs(difference);

        //default time from floor to floor is 7 seconds, with an additional 2 seconds per extra floor
        return ((positiveDifference - 1) * 2) + 7;

    }
    
    public String getMessage(){
        return message;
    }

    public void receivePacket(){
        byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);
        //System.out.println("Server: Waiting for Packet.\n");

        try {
            //System.out.println("Waiting...");
            receiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("Receive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }


        // The string we received from the floor
        String received = new String(data, 0, receivePacket.getLength());
        
        if(receivePacket.getPort() <= 4999){ // floor ports ----------------------------------------------------
        	// convert the string back into an array.
        	received = received.replace("[", "");
        	received = received.replace("]", "");

        	String[] receivedArr = received.split(", ");

        	//time = receivedArr[0];
        	currentFloor = receivedArr[0];
        	direction = receivedArr[2];
        	
        	System.out.println("--------------------------" + currentFloor);////////////////////////////
        	System.out.println("--------------------------" + direction);//////////////////////////////
        	
        	//destination = receivedArr[3];
        	//requestedFloor.add(receivedArr[1]);
                
        	int elevatorIndex = 0;
        	
        	for(int i = 0; i < elevatorCars.size(); i ++) {
        		if(elevatorCars.get(i).getCurrentFloor() == floorPorts.indexOf(Integer.toString(receivePacket.getPort()))) {
        			elevatorIndex = i;
        		}
        	}
        	
        	
        	System.out.println("A request for an elevator has been made on floor " + currentFloor + " they want to go " + direction);
        	//System.out.println("A request for an elevator has been made at " + time + " on floor " + currentFloor + " they want to go " + direction);
        	if(elevatorCars.get(elevatorIndex).getCurrentFloor() < Integer.parseInt(currentFloor.trim())) {
        		message = "directionUp";
        		byte msg[] = message.getBytes();
        		System.out.println("Sending signal to Floor " + (5000 - receivePacket.getPort()) + " to set direction lamp...");
        		sendPacket(msg, receivePacket.getPort(), floorPorts.get(0));
        	} else if (elevatorCars.get(elevatorIndex).getCurrentFloor() > Integer.parseInt(currentFloor.trim())) {
        		message = "directionDown";
        		byte msg[] = message.getBytes();
        		System.out.println("Sending signal to Floor " + (5000 - receivePacket.getPort()) + " to set direction lamp...");
        		sendPacket(msg, receivePacket.getPort(), floorPorts.get(0));
        	}
        	
        	String[] temp = new String[2];
        	
        	temp[0] = currentFloor.trim();
        	temp[1] = direction.trim();
        	
        	requestedFloor.add(temp);
        	
               

        	/*String request = "requestedFloor-"+ currentFloor.trim();
        	byte elevator[] = request.getBytes();
        	System.out.println("Sending current floor data to Elevator system..");
        	sendPacket(elevator, 5002, elevatorPorts.get(0));

        	door = "closeDoor";
        	byte closeDoor[] = door.getBytes();
        	System.out.println("Sending signal to Elevator to close door...");
        	sendPacket(closeDoor, 5002, elevatorPorts.get(0));*/
            
        	// ^^^ Moved to run()

        } else if(receivePacket.getPort() >= 5001){ // elevator ports  ----------------------------------------------------
            
        	String[] receivedArr = null;
        	
        	//String elevatorCurrentFloor;
        	
        	if(received.contains("-")) {
        		receivedArr = received.split("-");
        		received = receivedArr[0];
        		//elevatorCurrentFloor = receivedArr[1];
        	}
        	
        	int elevatorIndex = 0;
        	int floorPort = 0;
        	
        	for(int i = 0; i < elevatorCars.size(); i ++) {
        		if(elevatorCars.get(i).getPort() == receivePacket.getPort()) {
        			elevatorIndex = i;
        			
        			floorPort = Integer.parseInt(floorPorts.get(elevatorCars.get(i).getCurrentFloor()));
        		}
        	}
        	
        	String door = "";
        	switch(received){
                case "motorStarted":

                	
                	/*
                	// Instead of setting the elevators direction here, we will set it when we pass the request tot eh elevator
                	 
                	for(int i = 0; i < elevatorCars.size(); i++) {				
                		if(elevatorCars.get(i).getPort() == receivePacket.getPort()) {
                			elevatorCars.get(i).setDirection(receivedArr[1]);
                		}
                	}*/
                	
                    System.out.println("Elevator Started Moving...");
                    break;
                case "motorStopped":
                	
                	System.out.println("Elevator " + (5000 - floorPort) + " Direction = --" + elevatorCars.get(elevatorIndex).getDirection() + "--");
                	
                    if(elevatorCars.get(elevatorIndex).getDirection().equals("Up")) {
                        message = "upButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor " + (5000 - floorPort) + " to turn button lamp off...");
                        sendPacket(msg, floorPort, floorPorts.get(0));

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to open door...");
                        sendPacket(openDoor, receivePacket.getPort(), elevatorPorts.get(0));
                    }else if(elevatorCars.get(elevatorIndex).getDirection().equals("Down")) {
                        message = "downButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor " + (5000 - floorPort) + " to turn button lamp off...");
                        sendPacket(msg, floorPort, floorPorts.get(0));

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to open door...");
                        sendPacket(openDoor, receivePacket.getPort(), elevatorPorts.get(0));
                    }
                    break;
                case "doorsOpened":
                	
                    message = "selectFloor-" + elevatorPorts.get(0) + "-" + receivePacket.getPort() + "-" + elevatorCars.get(elevatorIndex).getDirection();
                    byte msg[] = message.getBytes();
                    System.out.println("Sending signal to Floor " + (5000 - floorPort) + " at port " + floorPort + " to send selected floor to Elevator...");
                    sendPacket(msg, floorPort, floorPorts.get(0));
                    break;
                case "doorsClosed":
                	
                	message = "startMotor";
                	
                	/*if(elevatorCars.get(elevatorIndex).getCurrentFloor() > Integer.parseInt(destination)) {
                		message = "startMotor-Down";
                	} else if (elevatorCars.get(elevatorIndex).getCurrentFloor() < Integer.parseInt(destination)) {
                		message = "startMotor-Up";
                	}*/ 
                	/*else {
                		System.out.println("It Broke :(");
                		break;
                	}*/
                	
                	msg = message.getBytes();
                    System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to start motor...");
                    sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                    break;
                case "destinationSelected":
                	//passengerFloor = Integer.parseInt(currentFloor.trim());
                    //destinationFloor = Integer.parseInt(destination.trim());
                	/*if(destinationFloor > passengerFloor) {
                		message = "UpDirectionLampOn";
                	} else if(destinationFloor < passengerFloor) {
                		message = "DownDirectionLampOn";
                	}else {
                		message = "directionLampOff";
                	}*/
                	
                	/*msg = message.getBytes();
                    System.out.println("Sending signal to Floor to change direction lamp...");
                    sendPacket(msg, floorPort, floorPorts.get(0));*/
                	
                	
                	// Set the number of passengers currently in the elevator
                	for(int i = 0; i < elevatorCars.size(); i++) { // itterate over the list of elevator cars
                		if(elevatorCars.get(i).getPort() == receivePacket.getPort()) { // find the proper elevator car
                			elevatorCars.get(i).setNumPassengers(Integer.parseInt(receivedArr[1])); // set the number of passengers on the elevator (which was passed by the elevator)
                			
                			System.out.println("Elevator " + (receivePacket.getPort() - 5000) + " now has " + receivedArr[1] + " passengers");
                		}
                	}
                    
                    String doorState = "closeDoor";
                    byte closeDoor[] = doorState.getBytes();
                    System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to close door...");
                    sendPacket(closeDoor, receivePacket.getPort(), elevatorPorts.get(0));
                	break;
                case "elevatorArrived":
                	
                	// Set the elevators Current Floor
                	elevatorCars.get(elevatorIndex).setFloor(Integer.parseInt(receivedArr[1]));
                	
                	 System.out.println("The elevator " + (elevatorIndex + 1) + " has arrived at " + elevatorCars.get(elevatorIndex).getCurrentFloor());
                     

                	 
                	 if(receivedArr[2].equals("isDestination")) {
                		 message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                	 }
                	 
                	 if(receivedArr[3].equals("isFinalDestination")) {
                		 /*message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));*/
                	 } 
                	 else if(receivedArr[3].equals("isNotFinalDestination")) {
                		 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                	 }
                	 
                	 
                	 
                	 /*for(int i = 0; i < requestedFloor.size(); i++) {
                		 if(elevatorCurrentFloor.equals(requestedFloor.get(i)[0].trim())) {
                			 requestedFloor.remove(i);
                			 message = "stopMotor";
                             msg = message.getBytes();
                             sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                		 }
                	 }*/
                	 
                     /*if(elevatorCurrentFloor.equals(destination) && requestedFloor.size() == 0) {
                    	 message = "stopMotor";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));*/
                         
                         /**********
                          * 
                          * CHANGE
                          * 
                          **********/
                    	 /*message = "end";
                    	 msg = message.getBytes();
                    	 for(int i = 1; i < floorPorts.size(); i++) {// Send "end' Message to all floors
                    		 sendPacket(msg, Integer.parseInt(floorPorts.get(i)), floorPorts.get(0));
                    	 }
                    	 
                    	 for(int i = 1; i < elevatorPorts.size(); i++) { // Send "end' Message to all elevators
                    		 sendPacket(msg, Integer.parseInt(elevatorPorts.get(i)), elevatorPorts.get(0));
                    	 }
                         
                         System.out.println("Process finished, terminating process...");
                         running = false;*/
                         
                         /***************
                          * 
                          * 
                          ***************/
                         
                         
                     /*} else if(elevatorCurrentFloor.equals(destination) && requestedFloor.size() > 0) {
                    	 System.out.println("Continue Moving 1");
                    	 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                     }else if (!elevatorCurrentFloor.equals(destination) && requestedFloor.size() > 0) {
                    	 System.out.println("Continue Moving 2");
                    	 message = "continueMoving";
                         msg = message.getBytes();
                         sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                     }*/
                     break;
                default:
                	if(!received.equals("")) {
                		//elevator = Integer.parseInt(received);
                	}
                    break;
            }
        }

    }

    public void sendPacket(byte[] message, int port, String IP) {
        try {
			sendPacket = new DatagramPacket(message, message.length, InetAddress.getByName(IP), port);
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        if(port <= 4999) {
            try {
                sendFloorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else if (port >= 5001){
            try {
                sendElevatorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }


    @Override
    public void run() {
    	ArrayList<Integer> requestBeingService = new ArrayList<Integer>();
    	
    	while(running == true) {
    		
    		if(requestedFloor.size() != 0) {
    			
    			for(int i = 0; i < requestedFloor.size(); i ++) {
    				int tempPort = findClosest(Integer.parseInt(requestedFloor.get(i)[0]), requestedFloor.get(i)[1]);
    				
    				
    				if(tempPort != 0) { // the floors request is beign serviced
    					// Add the requested floor to the list of requests service
    					servicingRequests.add(requestedFloor.get(i));
    					
    					// Look through the list of elevator cars and set the direction of the desired car.
    					//	This will make it so that when the elevator reaches the floor it's supposed to be servicing, it will have the proper direction to serve already stores 
    					//	(instead of storing the direction the elevator is moving).
    					for(int j = 0; j < elevatorCars.size(); j++) {				
                    		if(elevatorCars.get(j).getPort() == tempPort) {
                    			elevatorCars.get(j).setDirection(requestedFloor.get(i)[1]);
                    		}
                    	}

    					// Send the requested floor to the elevator
    					String request = "requestedFloor-"+ requestedFloor.get(i)[0];
    		        	byte elevator[] = request.getBytes();
    		        	System.out.println("Requesting elevator " + (tempPort - 5000));
    		        	sendPacket(elevator, tempPort, elevatorPorts.get(0));

    		        	
    		        	
    		        	// Check if the elevator is already on the correct floor. if it is, open the doors. if not, close doors
    		        	String msg;
    		        	for(int j = 0; j < elevatorCars.size(); j++) {				
                    		if(elevatorCars.get(j).getPort() == tempPort) {
                    			if(elevatorCars.get(j).getCurrentFloor() == Integer.parseInt(requestedFloor.get(i)[0])) { // Elevator is already on correct floor. open dorrs.
                    				msg = "openDoor";
	               		        	byte closeDoor[] = msg.getBytes();
	               		        	System.out.println("Sending signal to Elevator " + (tempPort - 5000) + " to close door...");
	               		        	sendPacket(closeDoor, tempPort, elevatorPorts.get(0));
                    			}
                    			else { // elevator isn't already on correct floor. start the motor
                    				msg = "startMotor";
	               		        	byte closeDoor[] = msg.getBytes();
	               		        	System.out.println("Sending signal to Elevator " + (tempPort - 5000) + " to close door...");
	               		        	sendPacket(closeDoor, tempPort, elevatorPorts.get(0));
                    			}
                		        	
                    		}
    		        	
    		        	} // end of for each elevator car loop.
    		        	
    				}	
    			}
    			
    			// Now, iterate over the list of servicingRequests
    			for(int i = 0; i < servicingRequests.size(); i++) {
    				// Remove the value in requestedFloors if it's being serviced.
    				requestedFloor.remove(servicingRequests.get(i));
    			}
    			
    		}
    		
    		
    		receivePacket();
    	}
        sendFloorSocket.close();
        sendElevatorSocket.close();
        receiveSocket.close();
        //System.exit(0);
    }
}
