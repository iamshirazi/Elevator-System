import java.io.BufferedReader;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

public class FloorController {

    private ArrayList<Integer> floorPorts = new ArrayList<Integer>();
    private String[] message;
    private ArrayList<Thread> floorThreads = new ArrayList<Thread>();
    private String[] portNumbers;

    private int initialPort = 4999;
    private DatagramSocket sendSocket;
    private DatagramPacket sendPacket;
    private DatagramPacket receivePacket;
    private String received;
    private String floors;
    private int amountOfFloors;
    private ArrayList<Input> inputArray;
    private ArrayList<Long> sleepTimes;
    
    private String schedulerIP = "";
    
    public FloorController() {
    	inputArray = new ArrayList<>();
    	sleepTimes = new ArrayList<>();
    }
    
    public void initializeInputs() {
    	
    	Input input1 = new Input("48:30.0", "1", "Up", 6);
    	Input input2 = new Input("48:35.2", "4", "Down", 2);
    	Input input3 = new Input("48:40.5", "3", "Down", 1);
    	Input input4 = new Input("48:45.5", "6", "Down", 5);
    	
    	String time1 = input1.getTimeStamp();
    	String time2 = input2.getTimeStamp();
    	String time3 = input3.getTimeStamp();
    	String time4 = input4.getTimeStamp();
    	
    	long timeBetween12 = subtractTime(time1, time2);
    	long timeBetween23 = subtractTime(time2, time3);
    	long timeBetween34 = subtractTime(time3, time4);
    	
    	sleepTimes.add(timeBetween12);
    	sleepTimes.add(timeBetween23);
    	sleepTimes.add(timeBetween34);
    	
    	inputArray.add(input1);
    	inputArray.add(input2);
    	inputArray.add(input3);
    	inputArray.add(input4);
    	
    	byte[] data = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);
        
        int floorPortNum = 4999;
        
        for (int i = 0; i < inputArray.size(); i++) {
        	
        	if (i < inputArray.size()-1) {
	        	try {
					Thread.sleep(sleepTimes.get(i));
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        	if ((floorPortNum == 4999 && inputArray.get(i).getCallingFloor().equals(1)) || 
        			(floorPortNum == 4998 && inputArray.get(i).getCallingFloor().equals(2)) ||
        			(floorPortNum == 4997 && inputArray.get(i).getCallingFloor().equals(3)) ||
        			(floorPortNum == 4996 && inputArray.get(i).getCallingFloor().equals(4)) ||
        			(floorPortNum == 4995 && inputArray.get(i).getCallingFloor().equals(5)) ||
        			(floorPortNum == 4994 && inputArray.get(i).getCallingFloor().equals(6)) ||
        			(floorPortNum == 4993 && inputArray.get(i).getCallingFloor().equals(7))) {
        		
        		data = inputArray.get(i).getCallingFloor().getBytes();
	        	
	        	sendPacket = new DatagramPacket(data, data.length, receivePacket.getAddress(), floorPortNum);
	        	
				try {
					sendSocket.send(sendPacket);
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(1);
				}
        	}
			floorPortNum -= 1;
        }
        
        sendSocket.close();
    }
    
    public long subtractTime(String in1, String in2) {
    	
    	SimpleDateFormat formatter = new SimpleDateFormat("mm:ss.S");
    	Date d1 = new Date();
    	Date d2 = new Date();
		try {
			d1 = formatter.parse(in1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
		try {
			d2 = formatter.parse(in2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
    	long timeDiff = d2.getTime() - d1.getTime();
    	Date diff = new Date(timeDiff);
    	System.out.println(formatter.format(diff));
    	
    	long millis = diff.getTime();
    	
    	return millis;
    	
    }
    
    
    

    public void setupFloors() throws IOException {

        try { // Create a send and receive socket and assign it the port 5001
            sendSocket = new DatagramSocket(6000);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
        }

        byte[] inData = new byte[100];
        receivePacket = new DatagramPacket(inData, inData.length);

        //Prints out IP
        try {
            System.out.println(InetAddress.getLocalHost());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        readFloorInput();
        
        String[] message = new String[amountOfFloors];
        
        //Create Floor threads
        for(int i = 0; i < amountOfFloors; i++){
            floorThreads.add(new Thread(new Floor(i+1, initialPort, received), "Floor"+ 1));
            floorThreads.get(i).start();
            floorPorts.add(i, initialPort);
            message[i]= floorPorts.get(i).toString();
            initialPort--;
        }

        for(int i = 0; i < floorPorts.size(); i++){
            System.out.println(message[i]);
        }


        byte request[] = Arrays.toString(message).getBytes();
        
        
        try{
        	sendSocket.receive(receivePacket);
        }catch(UnknownHostException e){
        	e.printStackTrace();
        	System.exit(1);
        }
		
        received = new String(inData, 0, receivePacket.getLength());
        
        schedulerIP = received;
        
        try {
        	sendPacket = new DatagramPacket(request, request.length, InetAddress.getByName(schedulerIP), 6002);
        } catch (UnknownHostException e) {
        	e.printStackTrace();
        	System.exit(1);
        }
		
        try { // Send the Datagram packet to the correct port
        	sendSocket.send(sendPacket);
        } catch (IOException e) {
        	e.printStackTrace();
        	System.exit(1);
        }
        
        

        System.out.println("Floor ports sent to Scheduler");
        sendSocket.close();

    }

    public void readFloorInput(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("How many floors do you want in the system?");

        floors = scanner.nextLine();

        amountOfFloors = Integer.parseInt(floors);
    }


    /**
     *
    returns the amount of floors that the user
    inputted
     *param void
     */
    public int getAmountOfFloors(){
        return amountOfFloors;
    }





    public static void main(String[] args) throws IOException {
    	
        FloorController fc = new FloorController();
        
        fc.setupFloors();

        fc.initializeInputs();
        
        System.exit(0);

    }

}
