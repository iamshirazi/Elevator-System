import java.io.BufferedReader;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.time.*;

public class FloorController {

    private ArrayList<Integer> floorPorts = new ArrayList<Integer>();
    private String[] message;
    private ArrayList<Thread> floorThreads = new ArrayList<Thread>();
    private String[] portNumbers;

    private int initialPort = 4999;
    private DatagramSocket sendSocket;
    private DatagramPacket sendPacket;
    private DatagramPacket receivePacket;
    private String received;
    private String floors;
    private int amountOfFloors;
    private ArrayList<Input> inputArray;
    private ArrayList<Long> sleepTimes;
    private String FileName = "InputFile.txt";
    
    private String schedulerIP = "";
    
    public FloorController() {
    	inputArray = new ArrayList<>();
    	sleepTimes = new ArrayList<>();
    }
    
    public void initializeInputs() {
    	
    	
    	System.out.println("Reading Input");
    	
    	String[] messageArr = new String[4];
    	String[] tempArr;
    	
    	// Try to read the input file
    	try {
    		File myObj = new File(FileName);
    	      
    		Scanner myReader = new Scanner(myObj);
    	      
    		while (myReader.hasNextLine()) {
    	    	  
    			// get the line from the input file
    	        String data = myReader.nextLine(); 
    	        
    	        // Parse the data and create into a temporary array
    	        tempArr = data.split(", ");
    	        
    	        // Now use the data to initialize input objects and add them int the input array
    	        inputArray.add( new Input(tempArr[0], tempArr[1], tempArr[2], Integer.parseInt(tempArr[3])) );
    	        
    	        System.out.println(data);
    		}
    	      myReader.close(); // Close the reader
    	      
    	} catch (FileNotFoundException e) {
    		System.out.println("An error occurred.");
    		e.printStackTrace();
    	}
    	
    	//---------- DONE READING INPUT ----------//
    	
    	// Sort the input array
    	inputArray.sort(new TimeStampComparator());
    	
    	Collections.reverse(inputArray);
    	
    	
    	for(int i = 0; i < inputArray.size(); i++) {
    		System.out.println(inputArray.get(i).getTimeStamp());
    	}
    	
    	
    	byte[] data = new byte[100];
        //receivePacket = new DatagramPacket(data, data.length);
        
        int floorPortNum = 4999;
    	
    	
        System.out.println("reached forloop");
        
        for (int i = 0; i < inputArray.size(); i++) {
        	
        	if(i != 0) { // If it's not the first, index, then sleep the amount of time between the current timestamp and previous timstamp
        		try { // sleep
					Thread.sleep(  subtractTime(inputArray.get(i).getTimeStamp(), inputArray.get(i-1).getTimeStamp())  );
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
        	}
        	
        	messageArr[0] = inputArray.get(i).getCallingFloor();
        	messageArr[1] = Integer.toString(inputArray.get(i).getDestination());
        	messageArr[2] = inputArray.get(i).getDirection();
        	
        	floorPortNum = 5000-Integer.parseInt(inputArray.get(i).getCallingFloor());
        	
        	data = Arrays.toString(messageArr).getBytes();
        	
        	try {
        		System.out.println("Sending Packet from floor controller");
				sendPacket = new DatagramPacket(data, data.length, InetAddress.getLocalHost(), floorPortNum);
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
        	
			try {
				sendSocket.send(sendPacket);
			} catch (Exception e) {
				e.printStackTrace();
				System.exit(1);
			}
        }
        System.out.println("done for loop");
    }
    
    
    
    
    
    public long subtractTime(LocalTime in1, LocalTime in2) {
    	
    	long timeElapsed = Duration.between(in2, in1).toMillis();
    	return timeElapsed;
    	
    }
    
    
    

    public void setupFloors() throws IOException {

        try { // Create a send and receive socket and assign it the port 5001
            sendSocket = new DatagramSocket(6000);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
        }

        byte[] inData = new byte[100];
        receivePacket = new DatagramPacket(inData, inData.length);

        //Prints out IP
        try {
            System.out.println(InetAddress.getLocalHost());
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        readFloorInput();
        
        String[] message = new String[amountOfFloors];
        
        //Create Floor threads
        for(int i = 0; i < amountOfFloors; i++){
            floorThreads.add(new Thread(new Floor(i+1, initialPort, received), "Floor"+ 1));
            floorThreads.get(i).start();
            floorPorts.add(i, initialPort);
            message[i]= floorPorts.get(i).toString();
            initialPort--;
        }

        for(int i = 0; i < floorPorts.size(); i++){
            System.out.println(message[i]);
        }


        byte request[] = Arrays.toString(message).getBytes();
        
        
        try{
        	sendSocket.receive(receivePacket);
        }catch(UnknownHostException e){
        	e.printStackTrace();
        	System.exit(1);
        }
		
        received = new String(inData, 0, receivePacket.getLength());
        
        schedulerIP = received;
        
        try {
        	sendPacket = new DatagramPacket(request, request.length, InetAddress.getByName(schedulerIP), 6002);
        } catch (UnknownHostException e) {
        	e.printStackTrace();
        	System.exit(1);
        }
		
        try { // Send the Datagram packet to the correct port
        	sendSocket.send(sendPacket);
        } catch (IOException e) {
        	e.printStackTrace();
        	System.exit(1);
        }
        
        

        System.out.println("Floor ports sent to Scheduler");

    }

    public void readFloorInput(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("How many floors do you want in the system?");

        floors = scanner.nextLine();

        amountOfFloors = Integer.parseInt(floors);
    }


    /**
     *
    returns the amount of floors that the user
    inputted
     *param void
     */
    public int getAmountOfFloors(){
        return amountOfFloors;
    }





    public static void main(String[] args) throws IOException {
    	
        FloorController fc = new FloorController();
        
        fc.setupFloors();

        fc.initializeInputs();
        
        //System.exit(0);

    }

}
