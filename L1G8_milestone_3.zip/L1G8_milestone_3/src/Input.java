import java.time.*;
import java.time.format.DateTimeFormatter;

/********************************************************************
 * Input.java														*
 *																	*
 * Purpose:															*
 * 		- This class is an object class. 							*
 * 																	*
 * 		- The purpose of this class is to take in data from an 		*
 * 			input file so that it may pass the data to the 			*
 * 			scheduler												*
 * 																	*
 * @version 1.00 February 06, 2021									*
 * 																	*
 ********************************************************************/


public class Input {

	LocalTime timestamp;
    String callingFloor;
    String direction;
    int    destination;


    Input(CharSequence timestamp, String callingFloor, String direction, int destination){
    	
        this.timestamp = LocalTime.parse(timestamp,  DateTimeFormatter.ofPattern("HH:mm:ss.SSS"));
        this.callingFloor = callingFloor;
        this.direction = direction;
        this.destination = destination;
    }

    public LocalTime getTimeStamp() {
        return this.timestamp;
    }

    public String getCallingFloor() {
        return this.callingFloor;
    }
    
    public String getDirection() {
        return this.direction;
    }
    
    public int getDestination() {
        return this.destination;
    }
}
