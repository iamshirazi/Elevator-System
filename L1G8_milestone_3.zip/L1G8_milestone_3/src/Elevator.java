/**
 * Creates an Elevator thread which sends and receives packets.
 */

import java.io.*;
import java.net.*;

/**
 * @author Matthew
 *
 */
public class Elevator implements Runnable {

	private DatagramPacket sendPacket, receivePacket;
	private DatagramSocket sendReceiveSocket;
	private int elevatorNum;
	private boolean[] carButtonSelected; 
	private boolean upDirectionalLampIsOn;
	private boolean downDirectionalLampIsOn;
	private boolean motorOn;
	private boolean doorsOpen;
	private String direction = "";
	private int currentFloorNumber; // Floor that the Elevator is currently on.
	private int passengerNum;	// Keeps track of the total number of passengers on the elevator
	private int[] passengerDestination; // keeps track of how many passengers are going to a certain destination
	private boolean running; // When elevator has picked up the passenger and reached the passenger's destination, running = false. True otherwise.
	String message;
	String schedulerIP;
	
	
	public Elevator(int port, String schedulerIP, int numFloors) {
		
		System.out.println("There are " + numFloors + " Floors");
		
		elevatorNum = port-5000; // ports for elevators start at 5001, so elevator 1 = port - 5000 = 5001 - 5000 = 1
		upDirectionalLampIsOn = false;
		downDirectionalLampIsOn = false;
		motorOn = false;
		doorsOpen = false;
		currentFloorNumber = 0;
		running = true;
		direction = "None";
		passengerNum = 0;
		
		this.schedulerIP = schedulerIP;	
		
		carButtonSelected = new boolean[numFloors];
		passengerDestination = new int[numFloors];
		
		for(int i = 0; i < carButtonSelected.length; i++) {
			carButtonSelected[i] = false; // set the car button to off by default
			passengerDestination[i] = 0;  // set number of passengers heading to that floor to 0 by default
		}
		
		System.out.println("There are " + carButtonSelected.length + "Car Buttons");
		
		
		try {

			sendReceiveSocket = new DatagramSocket(port);

		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
	}
	
	public String getMessage(){
        return message;
    }
	
	public void stopRunning() { 
		running = false; 
		sendReceiveSocket.close();
	}

	/**
	 * Finds the button pressed and sets it to true.
	 * 
	 * @param floor_num
	 * @return
	 */
	public boolean isButtonSelected(int floor_num) {
		return carButtonSelected[floor_num - 1] = true; // Floor - 1 because floor 1 is at position 0 in array.
	}

	/**
	 * Returns if the up button was pressed.
	 * 
	 * @return
	 */
	public boolean isUpDirectionLampOn() {
		return upDirectionalLampIsOn;
	}

	/**
	 * Returns if the down button was pressed.
	 * 
	 * @return
	 */
	public boolean isDownDirectionLampOn() {
		return downDirectionalLampIsOn;
	}

	/**
	 * Sets the corresponding button lamp to true, depending on which button is
	 * pressed.
	 * 
	 * @param direction
	 */
	public void setDirectionLamp(String direction) {
		if (direction.equals("Up")) {
			downDirectionalLampIsOn = false;
			upDirectionalLampIsOn = true;
		} else if (direction.equals("Down")) {
			upDirectionalLampIsOn = false;
			downDirectionalLampIsOn = true;
		} else {
			upDirectionalLampIsOn = false;
			downDirectionalLampIsOn = false;
		}
	}
	
	/**
	 * Turns elevator on in a specified direction.
	 * 
	 * @param direction
	 */
	public void startElevator(String dir) {
		
		motorOn = true;
		String message = "motorStarted-" + dir;
		byte msg[] = message.getBytes();
        sendPacket(msg, 5000);
        try {
        	Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
	}

	/**
	 * Stops the elevator.
	 */
	public void stopElevator() {
		motorOn = false;
	}

	/**
	 * Opens the elevator doors.
	 */
	public void openDoors() {
		doorsOpen = true;
	}

	/**
	 * Closes the elevator doors.
	 */
	public void closeDoors() {
		doorsOpen = false;
	}

	/**
	 * Receives packet and unpacks it, then calls sendPacket method.
	 */
	public void receivePacket() {
		message = "";
		
		byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);

        try {
            System.out.println("Waiting...");
            sendReceiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("sendReceive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }
        
        // Gets message and turns it into a String.
        String received = new String(data,0,receivePacket.getLength());  
        
        String[] receivedArr = null;
        String direction = "";
    	
        /*
         * Splits the string if the message contained a direction. 
         * The elevator has to go either Up or Down to the passenger's chosen destination.
         * Direction is either Up (elevator goes Up to the destination) or Down.
         */
    	if(received.contains("-")) {
    		receivedArr = received.split("-");
    		received = receivedArr[0];
    		
    		System.out.println("-------------------------------------------");
    		System.out.println("Elevator: " + elevatorNum);
    		if(Integer.parseInt(receivedArr[1]) != 0) {	// First, we check to make sure that the first index is not 0. if it is, then nothing gets passed.
    			for(int i = 1; i < receivedArr.length; i++) {	// Set the buttons for the desired floors to true.
        			System.out.println("i = " + i);
        			System.out.println("receivedArr length = " + receivedArr.length);
        			System.out.println("carButtonSelected size = " + carButtonSelected.length);
    				carButtonSelected[Integer.parseInt(receivedArr[i])-1] = true;  // we use Integer.parseInt(receivedArr[i])-1 because floors start at 1 and the carButtonSelects list starts at index 0.
    			}
    		}
    		
    		System.out.println("-------------------------------------------");
    		
    	}else if(received.contains("=")) {
            receivedArr = received.split("=");
            received = receivedArr[0];
            currentFloorNumber = Integer.parseInt(receivedArr[1]);
        }
    	
    	///////////////////////////
    	System.out.println("ELEVATOR " + elevatorNum + " CURRENT FLOOR IS: " + currentFloorNumber);
    	
    	direction = "None"; // set the direction to Non
    	
    	// Now check if the elevator has to move. if it does, set the direction apropriatly
    	for(int i = 0; i < carButtonSelected.length; i++) {
    		
			if(carButtonSelected[i] == true && i < (currentFloorNumber-1)) {	// We use (currentFloorNumber-1) because the floors start at floor 1, but the buttons starts at index 0
				direction = "Down";
			}
			else if (carButtonSelected[i] == true && i > (currentFloorNumber-1)){
				direction = "Up";
			}
		}
    	
    	// Sets direction to "Up" or "Down"
    	setDirectionLamp(direction); 
        
    	/*
    	 * All these if statements do a specific task for a specific message.
    	 * Sends a response message at the very end.
    	 */
    	if(received.equals("setFloor")) {
            System.out.println("Elevator " + elevatorNum + " is on floor: " + currentFloorNumber);
        }
    	else if (received.equals("stopMotor")) {
        	System.out.println("");
			System.out.println("Stopping Elevator " + elevatorNum + "'s Motor");
			
        	stopElevator();
        	message = "motorStopped";
        }
        
        else if (received.equals("startMotor"))  {
        	System.out.println("");
			System.out.println("Starting elevator " + elevatorNum + "'s Motor");
        	startElevator(direction);
        	
        	try {
            	Thread.sleep(3000);
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
        	if(upDirectionalLampIsOn) {
        		currentFloorNumber++;
        	} else if(downDirectionalLampIsOn) {
        		currentFloorNumber--;
        	} else {
        		System.out.println("Something's not right here (elevator " + elevatorNum + ")............");
        	}
        	System.out.println("");
			//System.out.println("Elevator is at floor: " + currentFloorNumber);
        	
        	String isDestination = "";
        	String isFinalDestination;
        	
        	// check if the current floor is a destination
        	if(carButtonSelected[currentFloorNumber-1] == true) {
        		isDestination = "isDestination"; // set the destination to true
        		carButtonSelected[currentFloorNumber-1] = false; // turn off the button
        	} else if (carButtonSelected[currentFloorNumber-1] == false) {
        		isDestination = "isNotDestination";
        	}
        	
        	
        	// check if there are any future destinations
        	isFinalDestination = "isFinalDestination";
        	for(int i = 0; i < carButtonSelected.length; i++) {
        		if(carButtonSelected[i] == true) {
        			isFinalDestination = "isNotFinalDestination";
        		}
        	}
        	
        	// if the is not more destinations, (i.e., isFinalDestination == "isFinalDestination") then set the direction lamps to false 
        	if(isFinalDestination.equals("isFinalDestination")) {
        		upDirectionalLampIsOn = false;
        		downDirectionalLampIsOn = false;
        	}
        	
        	
        	message = "elevatorArrived-" + currentFloorNumber + "-" + isDestination + "-" + isFinalDestination;
        }
        else if (received.equals("openDoor")) {
        	System.out.println("");
			System.out.println("Opening Elevator " + elevatorNum + "'s Doors");

        	openDoors();
        	message = "doorsOpened";
        }
        else if (received.equals("closeDoor")) {
        	System.out.println("");
			System.out.println("Closing Elevator " + elevatorNum + "'s Doors");
        	
        	closeDoors();
        	message = "doorsClosed";
        }
        else if(received.equals("currentFloor")) {
        	System.out.println("");
			System.out.println("Sending Elevator " + elevatorNum + "'s Current Floor Number");
        	
        	message = String.valueOf(currentFloorNumber);
        }
        else if(received.equals("end")) {
        	running = false;
        	
        }
        else if(received.equals("continueMoving")) {
        	try {
            	Thread.sleep(4000); // 4 seconds per floor.
            }catch (InterruptedException e) {
                e.printStackTrace();
            }
        	if(upDirectionalLampIsOn) {
        		// Elevator continues UP a floor.
        		currentFloorNumber++;
        	} else if(downDirectionalLampIsOn) {
        		// Elevator continues moving DOWN a floor.
        		currentFloorNumber--;
        	}
        	System.out.println("");
			System.out.println("Elevator " + elevatorNum + " is at floor: " + currentFloorNumber);
			String isDestination = "";
        	String isFinalDestination;
        	
        	// check if the current floor is a destination
        	if(carButtonSelected[currentFloorNumber-1] == true) {
        		isDestination = "isDestination"; // set the destination to true
        		carButtonSelected[currentFloorNumber-1] = false; // turn off the button
        	} else if (carButtonSelected[currentFloorNumber-1] == false) {
        		isDestination = "isNotDestination";
        	}
        	
        	
        	// check if there are any future destinations
        	
        	isFinalDestination = "isFinalDestination";
        	for(int i = 0; i < carButtonSelected.length; i++) {
        		if(carButtonSelected[i] == true) {
        			isFinalDestination = "isNotFinalDestination";
        		}
        	}
        	
        	
        	message = "elevatorArrived-" + currentFloorNumber + "-" + isDestination + "-" + isFinalDestination;
        }
        else if(received.equals("requestedFloor")) {
        	System.out.println("Elevator " + elevatorNum + " received floor request");
        	
        	System.out.println("YOOOOOOOOOOOOOOOOOOOOOO: " + direction + ".........");////////////////////////////////////////
        	
        	if(direction.equals("Down")) {
        		upDirectionalLampIsOn = false;
        		downDirectionalLampIsOn = true;
        	} else if (direction.equals("Up")) {
        		upDirectionalLampIsOn = true;
        		downDirectionalLampIsOn = false;
        	} else {
        		upDirectionalLampIsOn = false;
        		downDirectionalLampIsOn = false;
        	}	
        }
        else if(received.equals("chooseFloor")) { // Message from floor
        	
        	// This clause is for when the elevator stops at a floor.
        	//	- The Elevator will either receive new destinations, or passengers will disembark, or both.
        	
        	if(Integer.parseInt(receivedArr[1]) == 0) { // no new passengers boarded the elevator
        		
        		System.out.println("No New Passengers boarded the Elevator");
        		
        	} else {
        		System.out.println("New Passenger(s) boarded the elevator.");
        		System.out.print("They Have Selected the Floor(s): ");
        		for(int i = 1; i < receivedArr.length; i++) {
        			System.out.print(receivedArr[i] + ", ");
        		}
        		System.out.println();
        		
        		// Set the passenger number and passengerDestination (i.e., the number of people going to that floor)
        		for(int i = 1; i < receivedArr.length; i ++) {
        			// add a passenger to the total amount of passengers heading to that floor
        			passengerDestination[Integer.parseInt(receivedArr[i]) - 1] += 1; // We use receivedArr[i]) - 1 because passengerDestination starts at index 0 but floors start at 1
        		
        			// Increment the total number of passengers on the elevator
        			passengerNum += 1;
        		}
        	}
        	
        	
        	// Now we check if anyone got off
        	passengerNum -= passengerDestination[currentFloorNumber-1]; // decrement by the number of people who requested this floor
        	
        	System.out.println(passengerDestination[currentFloorNumber-1] + " Passenger(s) Disembarked");
        	
        	
        	passengerDestination[currentFloorNumber-1] = 0; // set the number of people who desire this floor to 0
        	
        	carButtonSelected[currentFloorNumber-1] = false; // deselect the current floor button.
        	
			
			message = "destinationSelected-" + passengerNum; // let the scheduler know that destinations have been selected and tell the scheduler how many passengers are currently on the elevator
        }
        else {
        	System.out.println("Problem");

        	message = "";
        }
        /*
         * Message (regardless of what it is) is sent to the Scheduler.
         * Message is printed to the console.
         */
        System.out.println("Elevator " + elevatorNum + "'s  message = " + message);
        byte msg[] = message.getBytes();
        sendPacket(msg, 5000);
	}
	
	/**
	 * Sends packet to Scheduler.
	 */
	public void sendPacket(byte message[], int port) {

		sendPacket = new DatagramPacket(message, message.length, receivePacket.getAddress(), port);

		try {
	         sendReceiveSocket.send(sendPacket);
	      } catch (Exception e) {
	         e.printStackTrace();
	         System.exit(1);
	      }
	}

	@Override
	public void run() {
		while(running == true) {
    		receivePacket();
    	}
		sendReceiveSocket.close();
		System.out.println("");
		/*
		 * When Elevator is not running, Elevator thread ends.
		 */
		System.out.println("---- done ----");
		System.exit(0);
	}
}
