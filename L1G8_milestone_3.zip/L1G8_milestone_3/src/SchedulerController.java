import java.io.IOException;
import java.net.*;
import java.util.ArrayList;


public class SchedulerController {
	

    
    public static void main(String[] args) {
    	
    	String elevatorIP;
    	String floorIP;
    	DatagramSocket socket;
    	DatagramPacket sendPacket;
    	DatagramPacket receivePacket;
    	String received;
    	byte inData[];
    	String[] receivedArr;
    	
    	// Set up the arraylists for the elevator port and the floor ports
		ArrayList<String> floorIPandPorts = new ArrayList<String>();		// Make an arraylist that holds the Floor Subsystems IP and the ports of all the floors
		ArrayList<String> elevatorIPandPorts = new ArrayList<String>();		// Make an arraylist that holds the Elevator Subsystems IP and the ports of all the elevators
		
    	
    	
    	// First, get the Ip that the Scheduler will be using.
    	try { 
    		System.out.println("Scheduler IP = " + InetAddress.getLocalHost().getHostAddress());
    	} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	
    	try {
    		
    		
    		// Set the IP for the Elevator Subsystem and the IP for the Floor SubSystem
			floorIP = InetAddress.getLocalHost().getHostAddress();
			elevatorIP = InetAddress.getLocalHost().getHostAddress();
			
			// Make a datagram Socket
    		//	- Port 6002 = Scheduler Controller
    		//	- Port 6001 = Elevator Controller
    		//	- Port 6000 = Floor Controller
    		socket = new DatagramSocket(6002); 
    		
    		
    		// Add the floors and Elevators IP to their arrayList
    		floorIPandPorts.add(floorIP.toString());
    		elevatorIPandPorts.add(elevatorIP.toString());
			
			
			// Now, we will send the Scheduler subsystem IP address to the Floor and Elevator controllers 
    		//	which will be their signal to send their ArrayList of ports to SchduelerController.
    		
    		// Next, have the Scheduler Controller Send the Elevator Controller it's IP
    		byte[] sendIP = InetAddress.getLocalHost().getHostAddress().getBytes();	// Convert the IP of the Local host to a string and then to bytes.
    		
    		//---------------------------//
    		//-----  Contact Floor  -----//
    		//---------------------------//
    		
    		// --- Send the IP ---
    		sendPacket = new DatagramPacket(sendIP, sendIP.length, InetAddress.getByName(floorIP), 6000); // Set the Send Packet
    		
    		socket.send(sendPacket); // send the packet
    		
    		System.out.println("Done sending to Floor");
    		
    		// --- Receive the ports ---
    		// Initialize byte array to accept the message
    		inData = new byte[100];
    		
    		// initialize the receive packet 
    		receivePacket = new DatagramPacket(inData, inData.length);
    		
    		// Next, we receive the ports that are send by elevator
    		socket.receive(receivePacket);
    		
    		// Convert the message received to a string
            received = new String(inData, 0, receivePacket.getLength());
            
            System.out.println(received);
            
            // Convert the String to an array	
    		received = received.replace("[", "");
    		received  = received.replace("]", "");

    		receivedArr = received.split(", ");
    		
    		
    		// Now, pipe the ports we received from the packet into the proper ArrayList.
    		for(int i = 0; i < receivedArr.length; i++) {
    			if(receivedArr[i] != null) {
    				floorIPandPorts.add(receivedArr[i]);
    				System.out.println(receivedArr[i]);
    			}
    		}
    		
    		System.out.println("Done receiving from Floor");
    		
    		
    		
    		//------------------------------//
    		//-----  Contact Elevator  -----//
    		//------------------------------//

    		// --- Send the IP ---
    		sendPacket = new DatagramPacket(sendIP, sendIP.length, InetAddress.getByName(elevatorIP), 6001); // Set the Send Packet
    		
    		socket.send(sendPacket); // send the packet
    		
    		System.out.println("Done sending to elevator");
    		
    		
    		// --- Receive the ports ---
    		// Initialize byte array to accept the message
    		inData = new byte[100];
    		
    		// initialize the receive packet 
    		receivePacket = new DatagramPacket(inData, inData.length);
    		
    		// Next, we receive the ports that are send by elevator
    		socket.receive(receivePacket);
    		
    		// Convert the message received to a string
            received = new String(inData, 0, receivePacket.getLength());
            
            // Convert the String to an array	
    		received = received.replace("[", "");
    		received  = received.replace("]", "");

    		receivedArr = received.split(", ");
    		
    		
    		// Now, pipe the ports we received from the packet into the proper ArrayList.
    		for(int i = 0; i < receivedArr.length; i++) {
    			if(receivedArr[i] != null) {
    				elevatorIPandPorts.add(receivedArr[i]);	
    			}
    		}
    		
    		System.out.println("Done receiving from elevator");
    		
    		
    		// --- Send Elevator Controller the number of floors ---
    		int numFloors = (elevatorIPandPorts.size() - 1);
    		byte[] numFloorsMessage = Integer.toString(numFloors).getBytes();
    			
    		sendPacket = new DatagramPacket(numFloorsMessage, numFloorsMessage.length, InetAddress.getByName(elevatorIP), 6001); // Set the Send Packet
    		
    		socket.send(sendPacket); // send the packet
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	
    	
    	
 
        Thread scheduler = new Thread(new Scheduler(floorIPandPorts, elevatorIPandPorts), "scheduler");
        
        System.out.println("Starting scheduler...");
        scheduler.start();
    }
}