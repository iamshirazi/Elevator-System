public class ElevatorCar {

    private int currentFloor;
    private String Direction;
    private int Port;
    private int numPassengers;

    public ElevatorCar (int currentFloor, String Direction, int Port){
        this.Direction = Direction;
        this.currentFloor = currentFloor;
        this.Port = Port;
        numPassengers = 0;
    }


    public String getDirection() {
        return Direction;
    }
    
    public void setDirection(String direction) { Direction = direction; }

    public int getCurrentFloor() {
        return currentFloor;
    }
    
    public void setFloor(int floor) { currentFloor = floor; }
    
    public int getPort() {
        return Port;
    }
    
    public int getNumPassengers() {
    	return numPassengers;
    }
    
    public void setNumPassengers(int num) {
    	numPassengers = num;
    }
    
}