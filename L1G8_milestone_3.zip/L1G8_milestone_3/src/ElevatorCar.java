public class ElevatorCar {

    private int currentFloor;
    private String Direction;
    private int Port;

    public ElevatorCar (int currentFloor, String Direction, int Port){
        this.Direction = Direction;
        this.currentFloor = currentFloor;
        this.Port = Port;
    }


    public String getDirection() {
        return Direction;
    }
    
    public void setDirection(String direction) { Direction = direction; }

    public int getCurrentFloor() {
        return currentFloor;
    }
    
    public void setFloor(int floor) { currentFloor = floor; }
    
    public int getPort() {
        return Port;
    }
}