public class ElevatorCar {

	private int currentFloor;
	private String Direction; // Stores the intended direction
	private String movingDirection; // stores the direction it's currently moving
	private int Port;
	private int numPassengers;
	private boolean motorOn;
	private boolean doorsClosed;

	public enum Status {
		WORKING, STUCK, DOORSTUCK
	}

	private Status status;

	public ElevatorCar(int currentFloor, String Direction, int Port) {
		this.Direction = Direction;
		this.currentFloor = currentFloor;
		this.Port = Port;
		movingDirection = "None";
		numPassengers = 0;
		motorOn = false;
		doorsClosed = true;
		status = Status.WORKING;
	}

	/**
	 * Returns the direction the elevator needs to go to unload a passenger.
	 * 
	 * @return
	 */
	public String getDirection() {
		return Direction;
	}

	/**
	 * Returns the direction of the directionLamp.
	 * 
	 * @return
	 */
	public String getMovingDirection() {
		return movingDirection;
	}

	/**
	 * Sets the elevator's direction that it needs to go to unload a passenger.
	 * 
	 * @param direction
	 */
	public void setDirection(String direction) {
		Direction = direction;
	}

	/**
	 * Sets the direction of the directionLamp.
	 * 
	 * @param direction
	 */
	public void setMovingDirection(String direction) {
		movingDirection = direction;
	}

	/**
	 * Returns the floor that the elevator is currently on.
	 * 
	 * @return
	 */
	public int getCurrentFloor() {
		return currentFloor;
	}

	/**
	 * Sets the floor that the elevator is currently on.
	 * 
	 * @param floor
	 */
	public void setFloor(int floor) {
		currentFloor = floor;
	}

	/**
	 * Returns the port number of the elevator.
	 * 
	 * @return
	 */
	public int getPort() {
		return Port;
	}

	/**
	 * Returns the number of passengers currently inside the elevator.
	 * 
	 * @return
	 */
	public int getNumPassengers() {
		return numPassengers;
	}

	/**
	 * Sets the number of passengers inside the elevator.
	 * 
	 * @param num
	 */
	public void setNumPassengers(int num) {
		numPassengers = num;
	}

	/**
	 * Returns motorOn: either true or false.
	 * 
	 * @return
	 */
	public boolean getMotorState() {
		return motorOn;
	}

	/**
	 * Sets motorOn's state to true or false.
	 * 
	 * @param state
	 */
	public void setMotorState(boolean state) {
		motorOn = state;
	}

	/**
	 * Returns doorsClosed: either true or false.
	 * 
	 * @return
	 */
	public boolean getDoorsState() {
		return doorsClosed;
	}

	/**
	 * Sets doorsClosed to true or false.
	 * 
	 * @param state
	 */
	public void setDoorsState(boolean state) {
		doorsClosed = state;
	}

	/**
	 * Returns the status of the elevator, either: WORKING, STUCK, or DOORSTUCK.
	 * 
	 * @return
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * Sets the status of the elevator to WORKING, STUCK, or DOORSTUCK.
	 * 
	 * @param option
	 */
	public void setStatus(int option) {
		switch (option) {
		case 1:
			status = Status.WORKING;
			break;
		case 2:
			status = Status.DOORSTUCK;
			break;
		case 3:
			status = Status.STUCK;
			break;
		}
	}

}