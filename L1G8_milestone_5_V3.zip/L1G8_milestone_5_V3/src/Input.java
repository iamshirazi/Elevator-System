import java.time.*;
import java.time.format.DateTimeFormatter;

/********************************************************************
 * Input.java														*
 *																	*
 * Purpose:															*
 * 		- This class is an object class. 							*
 * 																	*
 * 		- The purpose of this class is to take in data from an 		*
 * 			input file so that it may pass the data to the 			*
 * 			scheduler												*
 * 																	*
 * @version 1.00 February 06, 2021									*
 * 																	*
 ********************************************************************/


public class Input {

    LocalTime timestamp;
    int callingFloor;
    String direction;
    int    destination;


    Input(CharSequence timestamp, int callingFloor, String direction, int destination){

        this.timestamp = LocalTime.parse(timestamp,  DateTimeFormatter.ofPattern("HH:mm:ss.SSS"));
        this.callingFloor = callingFloor;
        this.direction = direction;
        this.destination = destination;
    }

    /**
     * Returns the time value.
     * @return
     */
    public LocalTime getTimeStamp() {
        return this.timestamp;
    }

    /**
     * Returns the floor number that called the elevator.
     * @return
     */
    public int getCallingFloor() {
        return this.callingFloor;
    }

    /**
     * Return the direction the passenger wants to go.
     * @return
     */
    public String getDirection() {
        return this.direction;
    }

    /**
     * Returns the floor number the passenger wants to go to.
     * @return
     */
    public int getDestination() {
        return this.destination;
    }
}
