import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;
import java.util.Arrays;

import static org.junit.Assert.*;

public class ControllerTest {

    //Input inputFile = new Input("14:05:15.0", "1 ", "Up  ", 2);

    private Floor floor;
    private Elevator elevator;
    private Scheduler scheduler;
    DatagramPacket sendPacket;
    DatagramSocket sendSocket;



    @org.junit.Test
    public void floorTest() {
        floor = new Floor(1, 5000, "243.111.233");
        assertEquals(floor.getFloorNumber(), 1);
    }



    @org.junit.Test
    public void schedulerTest() {
        //scheduler = new Scheduler();

        String message = "doorsOpened";
        byte request[] = message.getBytes();

        try {
            sendSocket = new DatagramSocket(5002);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }

        try {
            sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5000);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try {
            sendSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        scheduler.receivePacket();


        assertEquals(scheduler.getMessage(), "selectFloor");
        sendSocket.close();
    }

    @org.junit.Test
    public void elevatorTest() {
        //elevator = new Elevator();

        String message = "openDoor";
        byte request[] = message.getBytes();

        try {
            sendSocket = new DatagramSocket(5000);
            sendSocket.setReuseAddress(true);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }

        try {
            sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5002);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try {
            sendSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        elevator.receivePacket();


        assertEquals(elevator.getMessage(), "doorsOpened");
        System.out.println(" elevator message = " + elevator.getMessage());

        sendSocket.close();

        elevator.stopRunning(); // This method just closses the port
    }

    @org.junit.Test
    public void floorControllerTest() throws IOException {
        FloorController fc = new FloorController();
        //Scheduler scheduler = new Scheduler();
        String input = "7";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);
        fc.setupFloors();
        byte request[] = new byte[100];

        try{
            sendSocket = new DatagramSocket(6001);
        }catch(SocketException e){
            e.printStackTrace();
            System.exit(1);
        }

        try {
            sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5000);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try {
            sendSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        scheduler.receivePacket();


        assertEquals(fc.getAmountOfFloors(), 7);
        sendSocket.close();


    }
}