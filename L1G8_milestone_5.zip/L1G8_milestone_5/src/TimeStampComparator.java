import java.util.Comparator;


public class TimeStampComparator implements Comparator<Input> {

    @Override
    public int compare(Input o1, Input o2) {
        // TODO Auto-generated method stub
        return o2.getTimeStamp().compareTo(o1.getTimeStamp());
    }

}
