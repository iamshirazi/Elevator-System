import javax.swing.*;



import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.lang.Math;

public class Scheduler extends JFrame implements Runnable{

    DatagramPacket sendPacket, receivePacket;
    DatagramSocket sendElevatorSocket, receiveSocket, sendFloorSocket;
    private String currentFloor;
    private String direction;
    private String message;
    private boolean running = true;
    private ArrayList<String[]> requestedFloor = new ArrayList<String[]>();
    private ArrayList<String[]> servicingRequests= new ArrayList<String[]>();
    private ArrayList<String> floorPorts = new ArrayList<String>();
    private ArrayList<String> elevatorPorts = new ArrayList<String>();
    private ArrayList<ElevatorCar> elevatorCars = new ArrayList<ElevatorCar>();
    private int preferableCapactity; // Represents the preferable Capacity of elevator cars
    private int maxCapacity;        // Represents the max Capacity of elevator cars
    private JFrame frame;
    private JButton[][] buttons;
    private int requestCounter;



    //-----  Scheduler Class Constructor  ------//
    public Scheduler(ArrayList<String> floorPorts, ArrayList<String> elevatorPorts, int preferableCapactity, int maxCapacity){

        requestCounter = 0;
    	
        try{ // Set up the Sockets
            sendFloorSocket = new DatagramSocket();
            sendElevatorSocket = new DatagramSocket();

            receiveSocket = new DatagramSocket(5000);
        } catch (SocketException e) {
            e.printStackTrace();
            System.exit(1);
        }

        // Set the arrayLists
        this.floorPorts = floorPorts;
        this.elevatorPorts = new ArrayList<String>(elevatorPorts);
        this.preferableCapactity = preferableCapactity;
        this.maxCapacity = maxCapacity;

        int curFloor;
        // create the elevator car objects
        for(int i = 1; i < elevatorPorts.size(); i++) {

            curFloor = (int) (Math.random() * ((floorPorts.size()-1) - 1 + 1) + 1);

            System.out.println(elevatorPorts.size());

            System.out.println(curFloor);
            System.out.println(elevatorPorts.get(i));
            System.out.println(elevatorPorts.get(0));
            elevatorCars.add(new ElevatorCar(curFloor, "None", Integer.parseInt(elevatorPorts.get(i)))); // create elevator care object

            // Send a Message to the elevator to set the floor of the elevator
            message = "setFloor=" + curFloor;
            byte[] msg = message.getBytes();
            sendPacket(msg, Integer.parseInt(elevatorPorts.get(i)), elevatorPorts.get(0));
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        setupGUI();
    } // End of Contructor


    public void setupGUI(){
        // Creates a new JFrame and places buttons in a grid layout
        int numRows = (floorPorts.size() - 1) + 5;
        int numColumns = elevatorPorts.size() + 2;

        frame = new JFrame("System GUI");
        buttons = new JButton[numRows][numColumns];

        frame.setLayout(new GridLayout(numRows, numColumns));

        // INITIALIZE ALL BUTTONS
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numColumns; j++) {
                buttons[i][j] = new JButton("");
            }
        }

        // Columns
        buttons[4][0] = new JButton("# of Up Requests");
        buttons[4][1] = new JButton("# of Down Requests");
        buttons[0][2] = new JButton("");
        

        for ( int n = 1 ; n < numColumns-2 ; n++ ) {
            buttons[0][n+2] = new JButton("Elevator "+ n ) ;
        }

        // status Rows
        buttons[1][2] = new JButton("Floor Number:");
        buttons[2][2] = new JButton("Elevator Direction:");
        buttons[3][2] = new JButton("Elevator Status:");
        buttons[4][2] = new JButton("# Passengers:");
        
        // Floor rows
        for(int i = 5; i < numRows; i++) {
        	buttons[i][2] = new JButton("Floor " + (i-4));
        }
        
        

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setSize(500, 500);

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numColumns; j++) {
                frame.add(buttons[i][j]);
            }
        }
        frame.setVisible(true);
    }

    public void updateStatusButtons() {
    	
    	// current floor 
    	// direction
    	int upCount;
    	int downCount;
    	
    	// Update the number of passengers on every floor
    	for(int i = 1; i < floorPorts.size(); i++) {
    		// set counts to 0
    		upCount = 0;
    		downCount = 0;
    		
    		// Get the upCount and downCount
    		for(String[] request : requestedFloor){
    			if((Integer.parseInt(request[0])) == i) { // correct floor
    				
    				if(request[1].equals("Up")) {
    					upCount++;
    				} 
    				else if (request[1].equals("Down")) {
    					downCount++;
    				}
    				else {
    					System.out.println("!!--" + request[1] + "--");
    				}
    			}
    		}
    		
    		for(String[] request : servicingRequests){
    			if(Integer.parseInt(request[0]) == i) { // correct floor
    				
    				if(request[1].equals("Up")) {
    					upCount++;
    				} 
    				else if (request[1].equals("Down")) {
    					downCount++;
    				}
    				else {
    					System.out.println("!!--" + request[1] + "--");
    				}
    			}
    		}
    		
    		// Set the button values
    		buttons[i+4][0].setText(makeString(upCount));
    		buttons[i+4][1].setText(makeString(downCount));
    	}
    	
    	
    	// Update elevator states
        for (int i = 0; i < elevatorCars.size(); i++) {
        	buttons[1][i+3].setText(makeString(elevatorCars.get(i).getCurrentFloor()));
        	buttons[2][i+3].setText(elevatorCars.get(i).getDirection());
        	buttons[3][i+3].setText(elevatorCars.get(i).getStatus().toString());
        	buttons[4][i+3].setText(makeString(elevatorCars.get(i).getNumPassengers()));
        	
        	// Reset button background colour
        	for(int j = 0; j < (floorPorts.size()-1); j++) {
        		buttons[j + 5][i+3].setBackground(null);
        	}
        	
        	if(elevatorCars.get(i).getStatus() == ElevatorCar.Status.DOORSTUCK || elevatorCars.get(i).getStatus() == ElevatorCar.Status.STUCK) {
        		// set background colour
            	buttons[elevatorCars.get(i).getCurrentFloor() + 4][i+3].setBackground(Color.RED);
        	}
        	else {
        		// set background colour
            	buttons[elevatorCars.get(i).getCurrentFloor() + 4][i+3].setBackground(Color.GREEN);
        	}
        	
        }
         
        frame.setVisible(true);
    }
    

    public String makeString(int floor) {
        return Integer.toString(floor);
    }


    //-----  findClosest(int, string) Method  -----//
    // - This method is used to determine the closest elevator to a requested floor and then assign that floor as a stop for the elevator.
    public int findClosest(int requestedFloorNumber, String direction) {
    	
    	if(elevatorCars.size() > 2) {
    		elevatorCars.get(2).setStatus(3);
    	}
    	if(elevatorCars.size() > 3) {
    		elevatorCars.get(3).setStatus(2);
    	}
    	
    	
        ArrayList<Integer[]> availableCars = new ArrayList<Integer[]>(); 	// Holds a list of the arrays of integers. The first index in the array is the index of a car (in the elevatorCarr arraylist) that is available. The second index is it's level of preference.
        int floorsAway = 100; 												// place holder. means that the closest elevator is 100 floors away
        int closestPort = 0; 												// holds the port of the closest elevator
        Integer[] preferredCar = new Integer[]{100, 100};					// Holds the index of the preferred car and it's level of preference
        boolean foundPreferred = false;										// tells us if we found a preferred elevator or not

        // Now, loop over the list of elevator cars
        for (int i = 0; i < elevatorCars.size(); i++) {
        	if(elevatorCars.get(i).getStatus() != ElevatorCar.Status.DOORSTUCK && elevatorCars.get(i).getStatus() != ElevatorCar.Status.STUCK) {
        		
        		if(elevatorCars.get(i).getDirection().equals("None")) {
        			elevatorCars.get(i).setMovingDirection("None");
        		}
        		
	            // First, loop over the list of elevator cars and retrieve the elevators that are
	            //  under the maximum capacity and that are not already heading in the wrong direction.
	            //  Add them into the list of available cars
        		if(elevatorCars.get(i).getDirection().equals("None") && (elevatorCars.get(i).getCurrentFloor() == 1 || elevatorCars.get(i).getCurrentFloor() == (floorPorts.size()-1))) {
        			availableCars.add(new Integer[] {i, 100});
        		}
        		
        		else if(elevatorCars.get(i).getNumPassengers() < maxCapacity && ( elevatorCars.get(i).getDirection().equals(direction) || elevatorCars.get(i).getDirection().equals("None") ) && ( elevatorCars.get(i).getMovingDirection().equals("None") || ( elevatorCars.get(i).getMovingDirection().equals("Up") && elevatorCars.get(i).getCurrentFloor() <= requestedFloorNumber ) || (elevatorCars.get(i).getMovingDirection().equals("Down") && elevatorCars.get(i).getCurrentFloor() >= requestedFloorNumber ) )) { // First check if they're going in your direction or if they're not moving
	          	
	                // Next, check if the car has passed you or not
	                if(direction.equals("Up") && elevatorCars.get(i).getCurrentFloor() < (requestedFloorNumber-2)  ) { availableCars.add(new Integer[] {i, 100}); } // adds the index of the car and set's it's preference to 100
	                else if(direction.equals("Down") && elevatorCars.get(i).getCurrentFloor() > (requestedFloorNumber + 2) ) { availableCars.add(new Integer[] {i, 100}); } // adds the index of the car and set's it's preference to 100
	                else {availableCars.add(new Integer[] {i, 100}); } // adds the index of the car and set's it's preference to 100
	
	
	            }
        	}
        }

        // Next, we iterate over the list of available cars and we choose the preferred car
        // Car Preference is ordered as follows:
        //	1. Car already moving in desired direction AND under preferred capacity
        //  2. Car not moving, BUT when moving it CAN pick up passenger on the way (if going up, elevator is bellow passenger. if going down, elevator is above passenger) (Also car is therefore by default under preferred capacity, since it's not moving)
        //  3. Car not moving AND when moving it CAN NOT pick up passenger on the way (if going up, elevator is Above passenger. if going down, elevator is Below passenger) (Also car is therefore by default under preferred capacity, since it's not moving)
        //
        //	4. Car already moving in desired direction AND is OVER preferred capacity BUT is UNDER Max Capacity
        // 	5. If there is no available cars, the floor will wait and try again later to be serviced.

        // The program will always pick whichever car is highest in the order of preference, however if two elevators are the same preference, it will pick the one that's closest


        // Now we loop over the available cars and assign them the proper preference
        for(int i = 0; i < availableCars.size(); i++){

            // Check for preference 1
            if( elevatorCars.get(availableCars.get(i)[0]).getDirection().equals(direction) && elevatorCars.get(availableCars.get(i)[0]).getNumPassengers() < preferableCapactity ) { availableCars.get(i)[1] = 1; }


            // Check for preference 2 and 3
            else if(elevatorCars.get(availableCars.get(i)[0]).getDirection().equals("None")) { // Check direction = None

                // Check for preference 2
                if( (direction.equals("Up") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() <= requestedFloorNumber)   ||   (direction.equals("Down") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() >= requestedFloorNumber) ) { availableCars.get(i)[1] = 2; }

                // Check for preference 3
                if( (direction.equals("Up") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() > requestedFloorNumber)   ||   (direction.equals("Down") && elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() < requestedFloorNumber) ) { availableCars.get(i)[1] = 3; }

            }

            // Check for preference 4
            else if( elevatorCars.get(availableCars.get(i)[0]).getDirection().equals(direction) && elevatorCars.get(availableCars.get(i)[0]).getNumPassengers() > preferableCapactity ) { availableCars.get(i)[1] = 4; }

        }


        // Next, compare the preferences. If two elevators have the same preference, pick the closest
        for(int i = 0; i < availableCars.size(); i++) {

            // Make sure the cars level of preference is between 1 and 4
            if(availableCars.get(i)[1] >= 1 && availableCars.get(i)[1] <= 4) {

                foundPreferred = true;

                // Check if the level of preference is smaller than the level of preference from the current preferred car.
                if(availableCars.get(i)[1] < preferredCar[1]) { // It is more preferred
                    preferredCar = availableCars.get(i); // current car is the new preferred car
                }
                else if(availableCars.get(i)[1] == preferredCar[1]) { // They are equal in preference

                    // Choose the closest one
                    // Checks the absolute value of the elevators current floor minus the request floor
                    if( Math.abs( elevatorCars.get(availableCars.get(i)[0]).getCurrentFloor() - requestedFloorNumber )   <   Math.abs( elevatorCars.get(preferredCar[0]).getCurrentFloor() - requestedFloorNumber )) {
                        preferredCar = availableCars.get(i);
                    }
                }
            }
        }

        // Now, return the port of the closest elevator.

        if(foundPreferred == true) { 	// We found a elevator car within our preference
            System.out.println("The preferred elevator is on floor: " + elevatorCars.get(preferredCar[0]).getCurrentFloor());

            closestPort = elevatorCars.get(preferredCar[0]).getPort();
            
            // Set the elevators moving direction
            if(elevatorCars.get(preferredCar[0]).getCurrentFloor() > requestedFloorNumber) {
            	elevatorCars.get(preferredCar[0]).setMovingDirection("Down");
            }
            else if(elevatorCars.get(preferredCar[0]).getCurrentFloor() < requestedFloorNumber) {
            	elevatorCars.get(preferredCar[0]).setMovingDirection("Up");
            }

            return closestPort;
        } else { 						// We did not find a elevator car within our preference

            return 0;
        }

    } // End of findClosest Method





    public int calculateTimeToWait(int floor1, int floor2){
        int difference = floor1 - floor2;
        int positiveDifference = Math.abs(difference);

        //default time from floor to floor is 7 seconds, with an additional 2 seconds per extra floor
        return ((positiveDifference - 1) * 2) + 7;

    }

    public String getMessage(){
        return message;
    }

    public void receivePacket(){	
        byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);
        try {
            receiveSocket.receive(receivePacket);
        } catch (IOException e) {
            System.out.print("IO Exception: likely:");
            System.out.println("Receive Socket Timed Out.\n" + e);
            e.printStackTrace();
            System.exit(1);
        }


        // The string we received from the floor
        String received = new String(data, 0, receivePacket.getLength());

        if(receivePacket.getPort() <= 4999){ // floor ports ----------------------------------------------------
            // convert the string back into an array.
            received = received.replace("[", "");
            received = received.replace("]", "");

            String[] receivedArr = received.split(", ");
            
            currentFloor = receivedArr[0];
            direction = receivedArr[2];

            System.out.println("--------------------------" + currentFloor);
            System.out.println("--------------------------" + direction);

            int elevatorIndex = 0;

            for(int i = 0; i < elevatorCars.size(); i ++) {
                if(elevatorCars.get(i).getCurrentFloor() == floorPorts.indexOf(Integer.toString(receivePacket.getPort()))) {
                    elevatorIndex = i;
                }
            }


            System.out.println("A request for an elevator has been made on floor " + currentFloor + " they want to go " + direction);
            //System.out.println("A request for an elevator has been made at " + time + " on floor " + currentFloor + " they want to go " + direction);
            if(elevatorCars.get(elevatorIndex).getCurrentFloor() < Integer.parseInt(currentFloor.trim())) {
                message = "directionUp";
                byte msg[] = message.getBytes();
                System.out.println("Sending signal to Floor " + (5000 - receivePacket.getPort()) + " to set direction lamp...");
                sendPacket(msg, receivePacket.getPort(), floorPorts.get(0));
            } else if (elevatorCars.get(elevatorIndex).getCurrentFloor() > Integer.parseInt(currentFloor.trim())) {
                message = "directionDown";
                byte msg[] = message.getBytes();
                System.out.println("Sending signal to Floor " + (5000 - receivePacket.getPort()) + " to set direction lamp...");
                sendPacket(msg, receivePacket.getPort(), floorPorts.get(0));
            }

            String[] temp = new String[2];

            temp[0] = currentFloor.trim();
            temp[1] = direction.trim();

            requestedFloor.add(temp);

        } else if(receivePacket.getPort() >= 5001){ // elevator ports  ----------------------------------------------------

            String[] receivedArr = null;

            //String elevatorCurrentFloor;

            if(received.contains("-")) {
                receivedArr = received.split("-");
                received = receivedArr[0];
            }

            int elevatorIndex = 0;
            int floorPort = 0;

            for(int i = 0; i < elevatorCars.size(); i ++) {
                if(elevatorCars.get(i).getPort() == receivePacket.getPort()) {
                    elevatorIndex = i;

                    floorPort = Integer.parseInt(floorPorts.get(elevatorCars.get(i).getCurrentFloor()));
                }
            }

            String door = "";
            switch(received){
                case "motorStarted":

                    elevatorCars.get(elevatorIndex).setMotorState(true);    
                    

                    System.out.println("Elevator " + (receivePacket.getPort() - 5000) + " Started Moving...");
                    updateStatusButtons();
                    break;
                case "motorStopped":

                    elevatorCars.get(elevatorIndex).setMotorState(false);

                    System.out.println("Elevator " + (receivePacket.getPort() - 5000) + " Direction = --" + elevatorCars.get(elevatorIndex).getDirection() + "--");

                    if(elevatorCars.get(elevatorIndex).getDirection().equals("Up")) {
                        message = "upButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor " + (5000 - floorPort) + " to turn button lamp off...");
                        sendPacket(msg, floorPort, floorPorts.get(0));

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to open door...");
                        sendPacket(openDoor, receivePacket.getPort(), elevatorPorts.get(0));
                        
                        
                        /*ArrayList<Integer> tempNum = new ArrayList<Integer>();
                        
                        // Remove the request from the serviced requests
                        for(int i = 0; i < servicingRequests.size(); i++) {
                        	if(Integer.parseInt(servicingRequests.get(i)[0]) == (5000 - floorPort) && servicingRequests.get(i)[1].equals("Up")) {
                        		tempNum.add(i);
                        	}
                        }
                        
                        for(int i = 0; i < tempNum.size(); i++) {
                        	servicingRequests.remove(tempNum.get(i));
                        }*/
                        
                        
                        updateStatusButtons();
                    }else if(elevatorCars.get(elevatorIndex).getDirection().equals("Down")) {
                        message = "downButtonLampOff";
                        byte msg[] = message.getBytes();
                        System.out.println("Sending signal to Floor " + (5000 - floorPort) + " to turn button lamp off...");
                        sendPacket(msg, floorPort, floorPorts.get(0));

                        door = "openDoor";
                        byte openDoor[] = door.getBytes();
                        System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to open door...");
                        sendPacket(openDoor, receivePacket.getPort(), elevatorPorts.get(0));
                        
                        updateStatusButtons();
                    }
                    break;
                case "doorsOpened":

                    elevatorCars.get(elevatorIndex).setDoorsState(false); // set the doors state to open

                    if((5000 - floorPort) == 1) { // bottom floor, only send values for up
                    	 message = "selectFloor-" + elevatorPorts.get(0) + "-" + receivePacket.getPort() + "-Up";
                    }
                    else if((5000 - floorPort) == (floorPorts.size()-1)) { // top floor
                    	message = "selectFloor-" + elevatorPorts.get(0) + "-" + receivePacket.getPort() + "-Down";
                    }
                    else {
                    	message = "selectFloor-" + elevatorPorts.get(0) + "-" + receivePacket.getPort() + "-" + elevatorCars.get(elevatorIndex).getDirection();
                    }
                    
                    
                    byte msg[] = message.getBytes();
                    System.out.println("Sending signal to Floor " + (5000 - floorPort) + " at port " + floorPort + " to send selected floor to Elevator...");
                    sendPacket(msg, floorPort, floorPorts.get(0));
                    updateStatusButtons();
                    break;
                case "doorsClosed":

                    System.out.println("Elevator " + (receivePacket.getPort() - 5000) + "'s doors are closed");

                    elevatorCars.get(elevatorIndex).setDoorsState(true); // set the doors state to closed
                    updateStatusButtons(); 
                    break;
                case "destinationSelected":

                	long startTime = System.nanoTime();
                	
                    // Set the number of passengers currently in the elevator
                    for(int i = 0; i < elevatorCars.size(); i++) { // itterate over the list of elevator cars
                        if(elevatorCars.get(i).getPort() == receivePacket.getPort()) { // find the proper elevator car
                            elevatorCars.get(i).setNumPassengers(Integer.parseInt(receivedArr[1])); // set the number of passengers on the elevator (which was passed by the elevator)
                            try {
                            	 Thread.sleep(4000); // TAKES FOUR SECONDS TO ENTER/EXIT THE ELEVATOR
                            } catch (InterruptedException e) {
                            	e.printStackTrace();
                            }
                            
                            
                            System.out.println("Elevator " + (receivePacket.getPort() - 5000) + " now has " + receivedArr[1] + " passengers");

                            elevatorIndex = i;
                        }
                    }

                    System.out.println("TIME TO LOAD/UNLOAD ELEVATOR: " + (System.nanoTime() - startTime) / Math.pow(10, 9));
                    
                    String doorState = "closeDoor";
                    byte closeDoor[] = doorState.getBytes();
                    System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to close door...");
                    sendPacket(closeDoor, receivePacket.getPort(), elevatorPorts.get(0));


                    // Now, check if the elevator needs to go anywhere else. If receivedArr[1](Number of passenger) and receivedArr[2] (remaining destinations) both equal 0, then then elevator doesn't have to go anywhere
                    if(Integer.parseInt(receivedArr[1]) == 0 && Integer.parseInt(receivedArr[2]) == 0) {
                        elevatorCars.get(elevatorIndex).setDirection("None");
                        updateStatusButtons(); //////////
                    }
                    else { // the elevator has other places to go. Start the motor
                        String motorState = "startMotor";
                        byte startMotor[] = motorState.getBytes();
                        System.out.println("Sending signal to Elevator " + (receivePacket.getPort() - 5000) + " to start motor...");
                        sendPacket(startMotor, receivePacket.getPort(), elevatorPorts.get(0));
                        updateStatusButtons(); ////////
                    }

                    break;

                case "elevatorArrived":

                    // Set the elevators Current Floor
                    elevatorCars.get(elevatorIndex).setFloor(Integer.parseInt(receivedArr[1]));

                    System.out.println("The elevator " + (elevatorIndex + 1) + " has arrived at " + elevatorCars.get(elevatorIndex).getCurrentFloor());



                    if(receivedArr[2].equals("isDestination")) {
                    	
                    	ArrayList<Integer> tempNum = new ArrayList<Integer>();
                        
                        // Remove the request from the serviced requests
                        for(int i = 0; i < servicingRequests.size(); i++) {
                        	if(Integer.parseInt(servicingRequests.get(i)[0]) == Integer.parseInt(receivedArr[1])  && servicingRequests.get(i)[1].equals(elevatorCars.get(elevatorIndex).getDirection())) {
                        		tempNum.add(i);
                        	}
                        }
                        
                        for(int i = 0; i < tempNum.size(); i++) {
                        	servicingRequests.remove((int)tempNum.get(i));
                        }
                    	

                        System.out.println("Telling Elevator to stop motor");
                        elevatorCars.get(elevatorIndex).setMotorState(false);
                        message = "stopMotor";
                        msg = message.getBytes();
                        sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                        updateStatusButtons();
                        requestCounter++;
                    }

                    else if(!receivedArr[2].equals("isDestination") && receivedArr[3].equals("isFinalDestination")) {


                    }
                    else if(receivedArr[3].equals("isNotFinalDestination")) {
                    	try {
                            Thread.sleep(1000);
                        }catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        elevatorCars.get(elevatorIndex).setMotorState(true);
                        message = "continueMoving," + receivedArr[1];
                        msg = message.getBytes();
                        sendPacket(msg, receivePacket.getPort(), elevatorPorts.get(0));
                        updateStatusButtons();
                    }
 
                    break;
                default:
                    break;
            }
        }

    }

    public void sendPacket(byte[] message, int port, String IP) {  	
        try {
            sendPacket = new DatagramPacket(message, message.length, InetAddress.getByName(IP), port);
        } catch (UnknownHostException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        if(port <= 4999) {
            try {
                sendFloorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        } else if (port >= 5001){
            try {
                sendElevatorSocket.send(sendPacket);
            } catch (IOException e) {
                e.printStackTrace();
                System.exit(1);
            }
        }
    }


    @Override
    public void run() {
        ArrayList<Integer> requestBeingService = new ArrayList<Integer>();

        long start = System.nanoTime();
        
        while(running == true) {
        
            if(requestedFloor.size() != 0) {

                for(int i = 0; i < requestedFloor.size(); i ++) {
                    int tempPort = findClosest(Integer.parseInt(requestedFloor.get(i)[0]), requestedFloor.get(i)[1]);


                    if(tempPort != 0) { // the floors request is beign serviced
                        // Add the requested floor to the list of requests service
                        servicingRequests.add(requestedFloor.get(i));

                        // Look through the list of elevator cars and set the direction of the desired car.
                        //	This will make it so that when the elevator reaches the floor it's supposed to be servicing, it will have the proper direction to serve already stores
                        //	(instead of storing the direction the elevator is moving).
                        for(int j = 0; j < elevatorCars.size(); j++) {
                            if(elevatorCars.get(j).getPort() == tempPort) {
                                elevatorCars.get(j).setDirection(requestedFloor.get(i)[1]);
                            }
                        }

                        // Send the requested floor to the elevator
                        String request = "requestedFloor-"+ requestedFloor.get(i)[0];
                        byte elevator[] = request.getBytes();
                        System.out.println("Requesting elevator " + (tempPort - 5000));
                        sendPacket(elevator, tempPort, elevatorPorts.get(0));



                        // Check if the elevator is already on the correct floor. if it is, open the doors. if not, close doors
                        String msg;
                        for(int j = 0; j < elevatorCars.size(); j++) {
                            if(elevatorCars.get(j).getPort() == tempPort) {
                                if(elevatorCars.get(j).getCurrentFloor() == Integer.parseInt(requestedFloor.get(i)[0]) && elevatorCars.get(j).getDoorsState() == true) { // Elevator is already on correct floor. open doors.
                                    elevatorCars.get(j).setDoorsState(false);
                                    msg = "stopMotor";
                                    byte stopMotor[] = msg.getBytes();
                                    System.out.println("Sending signal to Elevator " + (tempPort - 5000) + " to stop motor...");
                                    sendPacket(stopMotor, tempPort, elevatorPorts.get(0));
                    				/*msg = "openDoor";
	               		        	byte openDoor[] = msg.getBytes();
	               		        	System.out.println("Sending signal to Elevator " + (tempPort - 5000) + " to open door...");
	               		        	sendPacket(openDoor, tempPort, elevatorPorts.get(0));*/
                                }
                                else if(elevatorCars.get(j).getMotorState() == false){ // elevator isn't already on correct floor and the motor isn't already on. start the motor
                                    elevatorCars.get(j).setMotorState(true);
                                    msg = "startMotor";
                                    byte startMotor[] = msg.getBytes();
                                    System.out.println("Sending signal to Elevator " + (tempPort - 5000) + " to start motor...");
                                    sendPacket(startMotor, tempPort, elevatorPorts.get(0));
                                }

                            }

                        } // end of for each elevator car loop.

                    }
                }

                // Now, iterate over the list of servicingRequests
                for(int i = 0; i < servicingRequests.size(); i++) {
                    // Remove the value in requestedFloors if it's being serviced.
                    requestedFloor.remove(servicingRequests.get(i));
                }

            }
            receivePacket();
            
            
            System.out.println("Remaining Requests: ");
            
            for(int i = 0; i < servicingRequests.size(); i++) {
            	System.out.println("--> " + servicingRequests.get(i)[0] + ", " + servicingRequests.get(i)[1] );
            }
            
            
            
            
            
            
            if(servicingRequests.size() == 0 && requestedFloor.size() == 0 && requestCounter >= 2) {
            	boolean shouldStop = true;
            	
            	for(int i = 0; i < elevatorCars.size(); i++) {
            		if(!elevatorCars.get(i).getDirection().equals("None")) {
            			shouldStop = false;
            		}
            	}
            	
            	if(shouldStop == true) { running = false;}
            	
            }
            
            
        }
        
        System.out.println("All requests finished, system shutting down");
        
        long elapsedTime = (System.nanoTime() - start);

        System.out.println("Total Scheduler Time in seconds: " + (elapsedTime / Math.pow(10, 9)));
        
        sendFloorSocket.close();
        sendElevatorSocket.close();
        receiveSocket.close();
        System.exit(0);
    }
}
