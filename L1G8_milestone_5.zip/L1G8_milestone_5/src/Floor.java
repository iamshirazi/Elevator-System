
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;

public class Floor implements Runnable {

    // Floors Send packet and receive packet and floors Send an receive socket
    DatagramPacket sendPacket, receivePacket;
    DatagramSocket sendReceiveSocket;

    // Input Class Object
    Input input;

    // Which button has been selected (lamp turns on)
    private boolean upButtonLampIsOn;
    private boolean downButtonLampIsOn;


    // Which direction the elevator is going (direction lamp turns on)
    private boolean upDirectionalLampIsOn;
    private boolean downDirectionalLampIsOn;

    // Current Floor number
    private int floorNum;

    private boolean running = true;

    //The socket number of the elevator
    private int socketNum;

    //The Floor port number
    private int portNum;

    //The Scheduler's IP address
    private InetAddress schedulerIp;

    private ArrayList<Integer> destinationUp = new ArrayList<Integer>();
    private ArrayList<Integer> destinationDown = new ArrayList<Integer>();


    // Class constructor
    //   Takes in:
    //		- Array of Input class objects
    //		- integer
    Floor(int floorNum, int portNum, String schedulerIp)
    {
        upButtonLampIsOn = false;			// Default the floors up button lamp to off
        downButtonLampIsOn = false;			// Default the floors down button lamp to off
        upDirectionalLampIsOn = false;		// Default the floors up directional lamp to off
        downDirectionalLampIsOn = false;	// Default the floors down directional lamp to off
        this.floorNum = floorNum;		    // Set the floors id number
        this.portNum = portNum;             // Set the port number of the floor

        try {
            this.schedulerIp = InetAddress.getByName(schedulerIp); //setting the scheduler ip address
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        try { // Create a send and receive socket and assign it the port 5001
            sendReceiveSocket = new DatagramSocket(portNum);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }
    } // End of Constructor Class




    //--------------------------------------------//
    //-----     Getter and Setter Section    -----//
    //--------------------------------------------//

    // Check if the buttons on the up and down buttons are on
    public boolean isUpButtonLampOn(){
        return upButtonLampIsOn;
    }

    public boolean isDownButtonLampOn() {
        return downButtonLampIsOn;
    }

    // Check if the up or down directional lamps are on
    public boolean isDownDirectionalLampOn() {
        return downDirectionalLampIsOn;
    }

    public boolean isUpDirectionalLampOn() {
        return upDirectionalLampIsOn;
    }

    // sets the value of the up or down directional lamps
    public void setUpDirLampIsOn(boolean isOn) {
        upDirectionalLampIsOn = isOn;
    }

    public void setDownDirLampIsOn(boolean isOn) {
        downDirectionalLampIsOn = isOn;
    }


    public Input getInputFile(){
        return input;
    }

    public int getFloorNumber(){
        return floorNum;
    }



    //---------------------------------------------//
    //-----  End of Getter and Setter Section -----//
    //---------------------------------------------//


    //-----  processInput(Input) Method  -----//
    //  - This method is used to process the input passed to it and then call the sendPacket and receivePackets
    public void processInput(String[] input){

        System.out.println(input.length);

        // user presses button and it lights up the buttons
        if(input[2].equals("Up  ")){
            upButtonLampIsOn = true;
        }
        else if (input[2].equals("Down")){
            downButtonLampIsOn = true;
        }

        System.out.println("Floor Num = " + floorNum);
        System.out.println("input[1] = " + input[1]);

        // add the destinations to the list of desired destinations (destinationUp and destinationDown)
        if(Integer.parseInt(input[1]) > floorNum) {

            destinationUp.add(Integer.parseInt(input[1])); // add destination to destinationUp

        } else if(Integer.parseInt(input[1]) < floorNum){

            destinationDown.add(Integer.parseInt(input[1])); // add destination to destinationDown

        } else {
            System.out.println("Destination requested is on the same floor. Request is not being sent");
            return;
        }


        // process the input file
//        String[] inputArr = new String[4];
//        inputArr[0] = input.timestamp;
//        inputArr[1] = input.callingFloor;
//        inputArr[2] = input.direction;
//        inputArr[3] = Integer.toString(input.destination);

        // next we convert the array Input into a string, and then we convert the string into an array of bytes to send them.
        byte request[] = Arrays.toString(input).getBytes();

        System.out.println("");
        System.out.println("Floor " + floorNum + " at port " + portNum + " is Requesting Elevator. Contacting Scheduler");
        System.out.println("");

        sendPacket(request, 5000, schedulerIp); // Send request to scheduler

        System.out.println("");
        System.out.println("Floor " + floorNum + " Has Contacted Scheduler");
        System.out.println("");

    }  // End of processInput(Input) Method





    //-----  receivePacket() Method  -----//
    //  - This method is used to receive messages to the Elevator and Scheduler threads
    public void receivePacket(){

        System.out.println("Floor " + floorNum + " Receiving Packet");

        byte data[] = new byte[100];
        receivePacket = new DatagramPacket(data, data.length);


        // retrieve the data sent from the scheduler
        try {
            // Block until a datagram is received via receiveSocket
            sendReceiveSocket.receive(receivePacket);
        } catch(IOException e) {
            System.out.println("oops");
            e.printStackTrace();
            System.exit(1);
        }

        // convert the data to a string format
        String messageReceived = new String(data, 0, receivePacket.getLength());

        messageReceived = messageReceived.replace("[", "");
        messageReceived  = messageReceived.replace("]", "");

        String[] messageArray = messageReceived.split(", ");

        if(messageArray.length >= 2) {
            System.out.println(messageArray[0]);
            System.out.println(messageArray[1]);
            System.out.println(messageArray[2]);
            System.out.println(messageArray[3]);
        }

        System.out.println("Message = " + messageReceived);


        String[] receivedArr;
        String elevatorIP ="";
        String elevatorPort = "";
        String direction = "";
        if(messageReceived.contains("-")) {
            receivedArr = messageReceived.split("-");
            messageReceived = receivedArr[0];
            elevatorIP = receivedArr[1];
            elevatorPort = receivedArr[2];
            direction = receivedArr[3];
        }


        //---------------------------------------------//
        //-----     Start of Switch Statement     -----//
        //---------------------------------------------//

        // Switch statement to decide how to process the order from the scheduler.
        switch(messageReceived){

            case "directionNone":		// This is the case for if the elevator is already on the correct floor
                System.out.println("");
                System.out.println("Elevator not moving");
                System.out.println("set both Floor " + floorNum + "'s direction lamps off.");
                System.out.println("");
                upDirectionalLampIsOn = false;
                downDirectionalLampIsOn = false;
                break;

            case "directionUp":			// This case is for if the elevator is
                System.out.println("");
                System.out.println("set Floor " + floorNum + "'s Up direction lamps on.");
                System.out.println("");
                upDirectionalLampIsOn = true;
                downDirectionalLampIsOn = false;
                break;

            case "directionDown":
                System.out.println("");
                System.out.println("Elevator going down.");
                System.out.println("set Floor " + floorNum + "'s down direction lamps on.");
                System.out.println("");
                upDirectionalLampIsOn = false;
                downDirectionalLampIsOn = true;
                break;

            case "upButtonLampOff":
                System.out.println("");
                System.out.println("Turning Off Floor " + floorNum+ "'s Up Button Lamp");
                break;

            case "downButtonLampOff":
                System.out.println("");
                System.out.println("Turning Off Floor " + floorNum+ "'s Down Button Lamp");
                setDownDirLampIsOn(false);
                break;

            case "selectFloor":

                String message = "chooseFloor";


                if(direction.equals("Up")) { // The elevator that has arrived is going up

                    if(destinationUp.size() > 0) { // There are passengers on this floor that want to go up
                        for(int i = 0; i < destinationUp.size(); i++) {
                            System.out.println("Destination += " + destinationUp.get(i));
                            message+= "-" + destinationUp.get(i);
                        }
                        // Now clear the destinationUp array
                        destinationUp.clear();
                    }
                    else { // There are NO passengers on this floor that want to go up
                        message+= "-0"; // Send 0, meaning there is nobody on this floor who wants to go up.
                    }

                }
                else if(direction.equals("Down")) { // The elevator that has arrived is going down
                    if(destinationDown.size() > 0) { // There are passengers on this floor that want to go down
                        for(int i = 0; i < destinationDown.size(); i++) {
                            System.out.println("Destination += " + destinationDown.get(i));
                            message+= "-" + destinationDown.get(i);
                        }
                        // Now clear the destinationDown array
                        destinationDown.clear();
                    }else { // There are NO passengers on this floor that want to go down
                        message+= "-0"; // Send 0, meaning there is nobody on this floor who wants to go down.
                    }

                }

                System.out.println("Floor " + floorNum + " is sending Message: " + message);
                byte selectDestination[] = message.getBytes();
                System.out.println("");
                System.out.println("sending destination(s) to elevator");
                try {
                    sendPacket(selectDestination, Integer.parseInt(elevatorPort), InetAddress.getByName(elevatorIP));
                } catch (NumberFormatException | UnknownHostException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                break;

            case "End":
                System.out.println("");
                System.out.println("Elevator arrived at floor " + floorNum + ", notifying scheduler");
                running = false;
                break;

            default:
                System.out.println(messageArray.toString());
                processInput(messageArray);
                System.out.println("Floor " + floorNum + " Has Received a Message.");
                System.out.println("Message received = " + messageReceived);

                break;

        } // End of Switch Statements

    } // End of receivePacket()





    //-----  sendPacket() Method  -----//
    //  - This method is used to send messages to the Elevator and Scheduler threads
    public void sendPacket(byte[] message, int port, InetAddress IP){
        // port is either 5000 or 5002.
        //      5000 = scheduler
        //      5002 = elevator
        sendPacket = new DatagramPacket(message, message.length, IP, port);

        try { // Send the Datagram packet to the correct port
            sendReceiveSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    } // End of sendPacket()





    @Override
    public void run()
    {

        while(running == true){
            receivePacket();
        }
        sendReceiveSocket.close();
    }

}
