public class ElevatorCar {

    private int currentFloor;
    private String Direction;
    private int Port;
    private int numPassengers;
    private boolean motorOn;
    private boolean doorsClosed;
    public enum Status { WORKING, STUCK, DOORSTUCK}
    private Status status;

    public ElevatorCar (int currentFloor, String Direction, int Port){
        this.Direction = Direction;
        this.currentFloor = currentFloor;
        this.Port = Port;
        numPassengers = 0;
        motorOn = false;
        doorsClosed = true;
        status = Status.WORKING;
    }


    public String getDirection() {
        return Direction;
    }

    public void setDirection(String direction) { Direction = direction; }

    public int getCurrentFloor() {
        return currentFloor;
    }

    public Status getStatus(){
        return status;
    }

    public void setStatus(int option){
        switch (option){
            case 1:
                status = Status.WORKING;
                break;
            case 2:
                status = Status.DOORSTUCK;
                break;
            case 3:
                status = Status.STUCK;
                break;
        }
    }

    public void setFloor(int floor) { currentFloor = floor; }

    public int getPort() {
        return Port;
    }

    public int getNumPassengers() {
        return numPassengers;
    }

    public void setNumPassengers(int num) {
        numPassengers = num;
    }

    public boolean getMotorState() {
        return motorOn;
    }

    public void setMotorState(boolean state) {
        motorOn = state;
    }

    public boolean getDoorsState() {
        return doorsClosed;
    }

    public void setDoorsState(boolean state) {
        doorsClosed = state;
    }

}