import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.*;

import static org.junit.jupiter.api.Assertions.*;

class ElevatorTest {

    private Elevator elevator;
    DatagramPacket sendPacket;
    DatagramSocket sendSocket;

    @org.junit.jupiter.api.Test
    void startElevator() {

        try {
            sendSocket = new DatagramSocket(5000);
            sendSocket.setReuseAddress(true);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }

        String message = "setFloor";
        byte request[] = message.getBytes();

        try {
            sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5001);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try {
            elevator = new Elevator(5001, InetAddress.getLocalHost().getHostAddress(), 7);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        try {
            sendSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        elevator.receivePacket();
        //Injected the fault here, set doors open to true
        elevator.doorsOpen = true;
        elevator.startElevator("Up");
        assertEquals(elevator.getMessage(), "Error");


        sendSocket.close();
    }

    @org.junit.jupiter.api.Test
    void stopElevator() {

        try {
            sendSocket = new DatagramSocket(5000);
            sendSocket.setReuseAddress(true);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }

        String message = "stopMotor";
        byte request[] = message.getBytes();

        try {
            sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5001);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try {
            elevator = new Elevator(5001, InetAddress.getLocalHost().getHostAddress(), 7);
            elevator.doorsOpen = true;
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        try {
            sendSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        elevator.receivePacket();
        elevator.doorsOpen = false;
        elevator.stopElevator();
        assertEquals(elevator.getMessage(), "Error");

        sendSocket.close();

    }

    @org.junit.jupiter.api.Test
    void timeErrorTest() {
        try {
            sendSocket = new DatagramSocket(5000);
            sendSocket.setReuseAddress(true);
        } catch (SocketException se) {   // failed to create socket
            se.printStackTrace();
            System.exit(1);
        }

        String message = "startMotor";
        byte request[] = message.getBytes();

        try {
            sendPacket = new DatagramPacket(request, request.length, InetAddress.getLocalHost(), 5001);
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try {
            elevator = new Elevator(5001, InetAddress.getLocalHost().getHostAddress(), 7);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }

        elevator.carButtonSelected[0] = true;

        try {
            sendSocket.send(sendPacket);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }

        elevator.receivePacket();
        elevator.stopElevator();

        //If the time elapsed (elevator moving to floor) is greater than 5 seconds, then there is an error
        if(elevator.getTimeElapsed()/Math.pow(10, 9) > 5){
            System.out.println(elevator.getTimeElapsed()/Math.pow(10, 9));
            assertEquals(true,true);
        } else{
            assertEquals(true,false);
        }

        sendSocket.close();
    }

    }